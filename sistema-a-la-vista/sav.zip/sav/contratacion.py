"""Bandas de aprobación en SMMLV y comparación con el banco de precios."""
from __future__ import annotations
from .reglas import U, Umbrales

SMMLV = {2026: 1_750_905}  # Decreto 1469 de 2025; se actualiza cada enero
BANDAS = {
    "baja": "Gerencia zonal o gerencia del fondo",
    "media": "Comité de contratación con dos miembros independientes",
    "alta": "Consejo Directivo",
}


def en_smmlv(pesos: float, anio: int = 2026) -> float:
    return pesos / SMMLV[anio]


def banda(pesos: float, inmuebles: bool = False, anio: int = 2026) -> str:
    if pesos < 0:
        raise ValueError("el valor no puede ser negativo")
    s = en_smmlv(pesos, anio)
    if inmuebles or s > 10_000:
        return "alta"
    return "baja" if s <= 1_000 else "media"


def revisar_precios(items: list[dict], u: Umbrales = U) -> list[dict]:
    """items: [{item, ofertado, referencia}] → agrega razon y si exige justificación."""
    out = []
    for it in items:
        if it["referencia"] <= 0:
            raise ValueError(f"referencia inválida para {it['item']}")
        r = it["ofertado"] / it["referencia"]
        out.append({**it, "razon": round(r, 3), "atipico": r > u.precio_max})
    return out
