"""Evidencia de obra: huella, geocerca, coherencia de hora y sello de tiempo."""
from __future__ import annotations
import hashlib, hmac, json
from datetime import datetime, timezone
from typing import Protocol


def huella(contenido: bytes) -> str:
    return hashlib.sha256(contenido).hexdigest()


def dentro(punto: tuple[float, float], poligono: list[tuple[float, float]]) -> bool:
    """Punto en polígono por trazado de rayos. Coordenadas (lon, lat)."""
    if len(poligono) < 3:
        raise ValueError("el polígono necesita al menos tres vértices")
    x, y = punto
    adentro = False
    j = len(poligono) - 1
    for i in range(len(poligono)):
        xi, yi = poligono[i]
        xj, yj = poligono[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            adentro = not adentro
        j = i
    return adentro


TOLERANCIA_RELOJ_S = 120      # el sello RFC 3161 trae segundos enteros y el reloj de un teléfono se desvía: dos minutos de holgura


def hora_coherente(captura: datetime, sello: datetime, max_horas: int = 72, tolerancia_s: int = TOLERANCIA_RELOJ_S) -> bool:
    """La captura no puede ser posterior al sello (salvo la holgura del reloj) ni demasiado anterior."""
    return (captura - sello).total_seconds() <= tolerancia_s and (sello - captura).total_seconds() <= max_horas * 3600


def repetidas(huellas: list[str]) -> set[str]:
    vistas, rep = set(), set()
    for h in huellas:
        (rep if h in vistas else vistas).add(h)
    return rep


class AutoridadDeSellado(Protocol):
    nombre: str
    def sellar(self, huella_hex: str) -> dict: ...
    def verificar(self, huella_hex: str, sello: dict) -> bool: ...


class SelladoSimulado:
    """Sustituto local de una entidad de certificación digital.

    Firma con HMAC y una llave local: sirve para desarrollo y pruebas, NO tiene
    valor probatorio. En producción se reemplaza por un cliente RFC 3161 contra
    una ECD acreditada por el ONAC, con la misma interfaz.
    """
    nombre = "simulado-sin-valor-probatorio"

    def __init__(self, llave: bytes, reloj=lambda: datetime.now(timezone.utc)):
        self._llave, self._reloj = llave, reloj

    def _mac(self, huella_hex: str, ts: str) -> str:
        return hmac.new(self._llave, f"{huella_hex}|{ts}".encode(), hashlib.sha256).hexdigest()

    def sellar(self, huella_hex: str) -> dict:
        ts = self._reloj().isoformat()
        return {"autoridad": self.nombre, "ts": ts, "token": self._mac(huella_hex, ts)}

    def verificar(self, huella_hex: str, sello: dict) -> bool:
        return hmac.compare_digest(sello.get("token", ""), self._mac(huella_hex, sello.get("ts", "")))


def canonico(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
