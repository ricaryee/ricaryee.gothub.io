"""Canales de atención: WhatsApp y línea telefónica sobre el mismo asistente.

Lo que este módulo garantiza:
  - El número de quien escribe no se guarda, salvo cuando el caso pasa a una persona (sin número no hay cómo responderle).
  - Un mensaje que el proveedor reenvía se atiende una sola vez.
  - La consulta por ID-SISMO se responde con datos públicos, sin pasar por el modelo.
  - Todo lo que el asistente no puede responder con un documento oficial abre un caso para una persona.
"""
from __future__ import annotations
import hashlib, hmac, re
from datetime import date, datetime, timedelta, timezone
import httpx
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from . import bitacora, calendario, cifrado, config, idsismo
from .db import CasoAtencion, Contacto, DocumentoOficial, MensajeCanal, Proyecto
from .ia import agentes

CANALES = ("whatsapp", "voz")
MAX_POR_HORA = 20
MAX_TEXTO = 1000
DIAS_CASO = 10      # días hábiles; el mismo plazo que el asistente promete al pasar a una persona
AVISO = ("Soy el asistente automático del Sistema a la Vista. No guardo su número, salvo que su caso pase a una persona. "
         "Escriba BAJA cuando no quiera recibir más mensajes.")
MSG_BAJA = "Listo. No le escribiremos más por este medio. Si vuelve a escribir, lo atenderemos de nuevo."
MSG_LIMITE = "Recibimos muchos mensajes suyos en poco tiempo. Por favor escriba de nuevo en una hora."
MSG_SOLO_TEXTO = "Por ahora solo puedo leer mensajes de texto. Escriba su pregunta, por favor."
MESES = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
MSG_SALUDO = ("Hola. Puedo decirle cómo va una obra si me escribe su número de proyecto (empieza por SISMO26 y está en la valla), "
              "o responder preguntas con los documentos oficiales del Fondo. ¿Qué necesita saber?")
_SALUDO = re.compile(r"^\W*(hola|buen[oa]s(\s+(d[ií]as|tardes|noches))?|saludos|gracias|muchas gracias|ok|listo)\W*$", re.I)
_ID = re.compile(r"SISMO26-\d{5}-[A-Z]{3}-\d{6}", re.I)
_BAJA = re.compile(r"^\s*(baja|salir|stop|no m[aá]s)\s*[.!]*\s*$", re.I)


def seudonimo(numero: str) -> str:
    return hmac.new(config.SECRETO().encode(), ("contacto:" + re.sub(r"\D", "", numero)).encode(), hashlib.sha256).hexdigest()[:32]


def firma_valida(cuerpo: bytes, cabecera: str | None, secreto: str) -> bool:
    """Meta firma cada aviso con HMAC-SHA256 del cuerpo y el secreto de la aplicación: cabecera X-Hub-Signature-256."""
    if not secreto or not cabecera or not cabecera.startswith("sha256="):
        return False
    return hmac.compare_digest(cabecera[7:], hmac.new(secreto.encode(), cuerpo, hashlib.sha256).hexdigest())


def extraer_whatsapp(aviso: dict) -> list[dict]:
    """Saca los mensajes de un aviso de la API de WhatsApp en la nube. Ignora estados de entrega y lo que no entiende."""
    out = []
    for e in aviso.get("entry") or []:
        for c in e.get("changes") or []:
            for m in (c.get("value") or {}).get("messages") or []:
                if m.get("id") and m.get("from"):
                    out.append({"id": str(m["id"]), "de": str(m["from"]), "tipo": m.get("type", ""),
                                "texto": ((m.get("text") or {}).get("body") or "") if m.get("type") == "text" else ""})
    return out


class EmisorBandeja:
    """Sustituto de desarrollo: guarda lo que se enviaría."""
    nombre = "bandeja-de-desarrollo"
    def __init__(self): self.enviados: list[dict] = []
    def enviar(self, numero: str, texto: str) -> bool:
        self.enviados.append({"a": numero, "texto": texto}); return True


class EmisorWhatsApp:
    """API de WhatsApp en la nube (Meta). Exige SAV_WA_TOKEN y SAV_WA_TELEFONO_ID."""
    nombre = "whatsapp-cloud"
    def __init__(self, token: str, telefono_id: str, version: str = "v21.0", cliente: httpx.Client | None = None):
        self._url, self._token, self._c = f"https://graph.facebook.com/{version}/{telefono_id}/messages", token, cliente or httpx.Client(timeout=20)
    def enviar(self, numero: str, texto: str) -> bool:
        try:
            r = self._c.post(self._url, headers={"Authorization": "Bearer " + self._token},
                             json={"messaging_product": "whatsapp", "to": numero, "type": "text", "text": {"body": texto[:4000]}})
            return r.status_code < 300
        except httpx.HTTPError:
            return False


def emisor_por_defecto():
    if config.WA_TOKEN() and config.WA_TELEFONO_ID():
        return EmisorWhatsApp(config.WA_TOKEN(), config.WA_TELEFONO_ID(), config.WA_VERSION())
    return EmisorBandeja()


def _estado_publico(s: Session, texto: str) -> str | None:
    m = _ID.search(texto)
    if not m:
        return None
    ids = m.group(0).upper()
    p = s.get(Proyecto, ids) if idsismo.es_valido(ids) else None
    if not p:
        return f"No encuentro el proyecto {ids}. Revise el número: está en la valla de la obra."
    hitos = [h for c in p.contratos for h in c.hitos]
    pagados = sum(1 for h in hitos if h.estado == "pagado")
    firmados = sum(1 for c in p.contratos if c.firmado)
    return (f"{p.nombre}, en {p.municipio}. Contratos firmados: {firmados}. Hitos de pago: {len(hitos)}, pagados: {pagados}. "
            f"Cada pago tiene fotos y acta. Puede verlo en el portal buscando {ids}.")


def _para_voz(texto: str) -> str:
    return re.sub(r"\s*Fuente:\s*(.+?)\s*$", r" Esto lo dice el documento \1.", texto).replace("ID-SISMO", "número de proyecto")


def atender(s: Session, canal: str, numero: str, texto: str, id_externo: str, tipo: str = "text", motor=None, ahora: datetime | None = None) -> dict | None:
    """Devuelve {respuesta, paso_a_persona, caso} o None si el mensaje ya se había atendido o no lleva respuesta."""
    if canal not in CANALES:
        raise ValueError("canal desconocido")
    ahora = ahora or datetime.now(timezone.utc)
    clave = f"{canal}:{id_externo}"[:200]
    if s.execute(select(MensajeCanal.id).where(MensajeCanal.id_externo == clave)).first():
        return None
    quien = seudonimo(numero)
    c = s.get(Contacto, quien)
    nuevo = c is None
    if nuevo:
        c = Contacto(seudonimo=quien, canal=canal, primer_contacto=ahora); s.add(c)
    texto = (texto or "").strip()[:MAX_TEXTO]
    recientes = s.execute(select(func.count()).select_from(MensajeCanal).where(MensajeCanal.contacto == quien, MensajeCanal.ts >= ahora - timedelta(hours=1))).scalar()
    persona, caso, resp = False, None, None
    if recientes >= MAX_POR_HORA:
        resp = MSG_LIMITE if recientes == MAX_POR_HORA else ""       # se avisa una vez y luego se calla
    elif tipo != "text" or not texto:
        resp = MSG_SOLO_TEXTO
    elif _BAJA.match(texto):
        c.baja, resp = True, MSG_BAJA
    elif len(texto) < 3 or _SALUDO.match(texto):
        c.baja, resp = False, MSG_SALUDO                               # un saludo no abre un caso
    else:
        c.baja = False                                              # volver a escribir es volver a pedir atención
        resp = _estado_publico(s, texto)
        if resp is None:
            docs = [{"titulo": d.titulo, "texto": d.texto} for d in s.execute(select(DocumentoOficial).where(DocumentoOficial.vigente.is_(True)).order_by(DocumentoOficial.id)).scalars()]
            r = agentes.asistente(s, texto, docs, False, motor)
            resp, persona = r["respuesta"], r["paso_a_persona"] or r["respuesta"] == agentes.MSG_AUTENTICAR
            if persona:
                hoy = ahora.date()
                k = CasoAtencion(canal=canal, contacto=quien, numero=cifrado.cifrar(numero), pregunta=texto, abierto=hoy, vence=calendario.sumar_habiles(hoy, DIAS_CASO))
                s.add(k); s.flush(); caso = k.id
                bitacora.registrar(s, f"caso:{k.id}", "caso_abierto", "asistente", "sistema", {"canal": canal, "vence": k.vence})
                resp = (f"Esto debe atenderlo una persona. Su caso es el número {k.id}. Le responderemos por este medio a más tardar el "
                        f"{k.vence.day} de {MESES[k.vence.month - 1]}." if r["respuesta"] != agentes.MSG_SIN_FUENTE else
                        f"No encontré esa información en los documentos oficiales. Pasé su pregunta a una persona: caso número {k.id}. "
                        f"Le responderemos por este medio a más tardar el {k.vence.day} de {MESES[k.vence.month - 1]}.")
        if nuevo and canal == "whatsapp":
            resp = AVISO + "\n\n" + resp
    if canal == "voz" and resp:
        resp = _para_voz(resp)
    s.add(MensajeCanal(id_externo=clave, canal=canal, contacto=quien, ts=ahora, entrada_huella=hashlib.sha256(texto.encode()).hexdigest(), respuesta=resp or "", paso_a_persona=persona))
    s.commit()
    return {"respuesta": resp, "paso_a_persona": persona, "caso": caso} if resp else None
