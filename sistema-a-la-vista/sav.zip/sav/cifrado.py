"""Cifrado en reposo de los pocos datos personales que la plataforma guarda (hoy: el número de un caso abierto).
Fernet (AES-128-CBC con HMAC-SHA256) con una llave derivada de SAV_LLAVE_DATOS."""
import base64, hashlib
from cryptography.fernet import Fernet, InvalidToken
from . import config

PREFIJO = "c1:"


def _f() -> Fernet:
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(("datos:" + config.LLAVE_DATOS()).encode()).digest()))


def cifrar(texto: str) -> str:
    return PREFIJO + _f().encrypt(texto.encode()).decode() if texto else ""


def descifrar(guardado: str) -> str:
    if not guardado:
        return ""
    if not guardado.startswith(PREFIJO):
        return guardado                       # dato anterior al cifrado
    try:
        return _f().decrypt(guardado[len(PREFIJO):].encode()).decode()
    except InvalidToken:
        return ""                             # llave equivocada: no se revela nada
