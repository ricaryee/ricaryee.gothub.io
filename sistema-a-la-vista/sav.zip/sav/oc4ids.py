"""Publicación en OC4IDS 0.9.5 (Open Contracting for Infrastructure Data Standard)."""
from __future__ import annotations
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import Session
from .db import Evento, Proyecto

SECTOR = {"VIV": "socialHousing", "INS": "education", "AEV": "waterAndWaste", "REC": "economy", "APO": "socialHousing", "ALM": "cultureSportsAndRecreation"}


def paquete(s: Session, p: Proyecto, base_url: str = "https://example.org/api") -> dict:
    partes = [{"id": "fondo", "name": "Fondo de reconstrucción", "roles": ["publicAuthority", "buyer"]},
              {"id": "fiduciaria", "name": "Fiduciaria vocera", "roles": ["procuringEntity", "payer"]}]
    procesos = []
    for c in p.contratos:
        pid = f"contratista-{c.id}"
        partes.append({"id": pid, "name": c.contratista, "roles": ["supplier", "payee"]})
        proc = {"id": c.id_secop or f"contrato-{c.id}",
                "summary": {"ocid": f"ocds-sav-{c.id}", "title": p.nombre, "status": "active" if c.firmado else "pre-award",
                            "nature": ["construction"], "suppliers": [{"id": pid, "name": c.contratista}],
                            "contractValue": {"amount": c.valor_inicial, "currency": "COP"},
                            "finalValue": {"amount": c.valor_inicial + c.adiciones, "currency": "COP"}}}
        if c.oferentes:
            proc["summary"]["tender"] = {"procurementMethod": "open", "numberOfTenderers": c.oferentes}
        procesos.append(proc)
    proy = {"id": p.id_sismo, "title": p.nombre, "status": "implementation", "type": "rehabilitation",
            "sector": [SECTOR[p.sector]], "updated": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "budget": {"amount": {"amount": p.valor, "currency": "COP"}},
            "locations": [{"id": "1", "description": p.municipio or p.municipio_dane,
                           "address": {"locality": p.municipio, "countryName": "Colombia"}}],
            "parties": partes, "contractingProcesses": procesos, "language": "es"}
    huellas = s.execute(select(Evento.seq, Evento.tipo, Evento.huella).where(Evento.referencia == p.id_sismo).order_by(Evento.seq)).all()
    proy["x_bitacora"] = [{"seq": q, "tipo": t, "huella": h} for q, t, h in huellas]
    return {"uri": f"{base_url}/publico/oc4ids/{p.id_sismo}", "version": "0.9", "publishedDate": proy["updated"],
            "publisher": {"name": "Sistema a la Vista"}, "license": "https://creativecommons.org/publicdomain/zero/1.0/",
            "projects": [proy]}
