"""Conector de SECOP II por datos abiertos (datos.gov.co, API Socrata).

Conjuntos: «SECOP II - Contratos Electrónicos» (jbjy-vk9h) y «SECOP II - Procesos
de Contratación» (p6dx-8zbt). Solo se guardan los campos de la lista blanca: el
conjunto público trae datos que la plataforma no necesita (por ejemplo, cuentas
bancarias y documentos de personas naturales) y que no deben copiarse.
"""
from __future__ import annotations
from datetime import date, datetime
import httpx

BASE = "https://www.datos.gov.co/resource"
CONTRATOS, PROCESOS = "jbjy-vk9h", "p6dx-8zbt"
CAMPOS_CONTRATO = ("id_contrato", "proceso_de_compra", "nombre_entidad", "nit_entidad", "departamento", "ciudad", "estado_contrato",
                   "tipo_de_contrato", "modalidad_de_contratacion", "fecha_de_firma", "fecha_de_inicio_del_contrato",
                   "fecha_de_fin_del_contrato", "proveedor_adjudicado", "valor_del_contrato", "valor_pagado", "dias_adicionados",
                   "objeto_del_contrato", "urlproceso", "ultima_actualizacion", "es_grupo")
CAMPOS_PROCESO = ("id_del_proceso", "id_del_portafolio", "entidad", "nit_entidad", "nombre_del_procedimiento", "fase",
                  "fecha_de_publicacion_del", "precio_base", "modalidad_de_contratacion", "respuestas_al_procedimiento",
                  "proveedores_unicos_con", "adjudicado", "nombre_del_proveedor", "valor_total_adjudicacion", "urlproceso", "estado_resumen")
NO_COMPETITIVAS = ("contratación directa", "régimen especial")


def _fecha(v) -> date | None:
    try:
        return datetime.fromisoformat(v).date() if v else None
    except ValueError:
        return None


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _url(v) -> str | None:
    return v.get("url") if isinstance(v, dict) else v


def normalizar_contrato(f: dict) -> dict:
    return {"id_secop": f.get("id_contrato"), "proceso": f.get("proceso_de_compra"), "entidad": f.get("nombre_entidad"),
            "nit_entidad": f.get("nit_entidad"), "municipio": f.get("ciudad"), "departamento": f.get("departamento"),
            "estado": f.get("estado_contrato"), "tipo": f.get("tipo_de_contrato"), "modalidad": f.get("modalidad_de_contratacion"),
            "firma": _fecha(f.get("fecha_de_firma")), "inicio": _fecha(f.get("fecha_de_inicio_del_contrato")),
            "fin": _fecha(f.get("fecha_de_fin_del_contrato")), "contratista": f.get("proveedor_adjudicado"),
            "valor": _num(f.get("valor_del_contrato")), "pagado": _num(f.get("valor_pagado")),
            "dias_adicionados": int(_num(f.get("dias_adicionados"))), "objeto": f.get("objeto_del_contrato"),
            "url": _url(f.get("urlproceso")), "actualizado": f.get("ultima_actualizacion")}


def normalizar_proceso(f: dict) -> dict:
    modalidad = (f.get("modalidad_de_contratacion") or "").lower()
    return {"id": f.get("id_del_proceso"), "portafolio": f.get("id_del_portafolio"), "entidad": f.get("entidad"),
            "nombre": f.get("nombre_del_procedimiento"), "fase": f.get("fase"), "publicado": _fecha(f.get("fecha_de_publicacion_del")),
            "precio_base": _num(f.get("precio_base")), "modalidad": f.get("modalidad_de_contratacion"),
            "oferentes": int(_num(f.get("proveedores_unicos_con"))), "adjudicado": (f.get("adjudicado") or "").lower() in ("si", "sí"),
            "competitivo": not any(m in modalidad for m in NO_COMPETITIVAS),
            "valor_adjudicado": _num(f.get("valor_total_adjudicacion")), "url": _url(f.get("urlproceso"))}


class Secop2:
    def __init__(self, cliente: httpx.Client | None = None, app_token: str | None = None):
        self._c = cliente or httpx.Client(timeout=30, headers={"X-App-Token": app_token} if app_token else {})

    def _leer(self, conjunto: str, campos: tuple, donde: str, limite: int, pagina: int = 1000):
        desplazamiento = 0
        while desplazamiento < limite:
            n = min(pagina, limite - desplazamiento)
            r = self._c.get(f"{BASE}/{conjunto}.json", params={"$select": ",".join(campos), "$where": donde, "$limit": n,
                                                               "$offset": desplazamiento, "$order": campos[0]})
            r.raise_for_status()
            filas = r.json()
            yield from filas
            if len(filas) < n:
                return
            desplazamiento += n

    @staticmethod
    def _nit(nit: str) -> str:
        if not nit.isdigit():
            raise ValueError("el NIT solo lleva dígitos")
        return nit

    def contratos(self, nit_entidad: str, desde: date, limite: int = 5000) -> list[dict]:
        donde = f"nit_entidad='{self._nit(nit_entidad)}' AND fecha_de_firma >= '{desde.isoformat()}T00:00:00'"
        return [normalizar_contrato(f) for f in self._leer(CONTRATOS, CAMPOS_CONTRATO, donde, limite)]

    def procesos(self, nit_entidad: str, desde: date, limite: int = 5000) -> list[dict]:
        donde = f"nit_entidad='{self._nit(nit_entidad)}' AND fecha_de_publicacion_del >= '{desde.isoformat()}T00:00:00'"
        return [normalizar_proceso(f) for f in self._leer(PROCESOS, CAMPOS_PROCESO, donde, limite)]

    def esta_publicado(self, id_contrato: str) -> bool:
        if not id_contrato.replace(".", "").isalnum():
            raise ValueError("identificador de contrato inválido")
        r = self._c.get(f"{BASE}/{CONTRATOS}.json", params={"$select": "id_contrato", "$where": f"id_contrato='{id_contrato}'", "$limit": 1})
        r.raise_for_status()
        return bool(r.json())
