"""Simuladores con el mismo contrato de datos que tendrán las fuentes reales.

Fiducoldex, SIIF, RUD (UNGRD) y catastro (IGAC) no tienen todavía acuerdo de
intercambio. Cada simulador implementa la interfaz que usará el conector real,
para que el cambio sea de configuración y no de código.
"""
from __future__ import annotations
import hashlib, hmac
from datetime import date


def seudonimo(documento: str, sal: bytes) -> str:
    """Seudónimo irreversible que la UNGRD calcula en la fuente; la plataforma nunca ve el documento."""
    h = hmac.new(sal, documento.encode(), hashlib.sha256).hexdigest().upper()
    return f"HOG-{h[:4]}-{h[4:8]}"


class FiducoldexSimulado:
    """Archivo diario firmado de movimientos: [{fecha, id_sismo, hito, valor}] + firma HMAC del archivo."""
    def __init__(self, llave: bytes):
        self._llave = llave

    def firmar(self, movimientos: list[dict]) -> dict:
        from ..evidencia import canonico
        cuerpo = canonico(movimientos)
        return {"movimientos": movimientos, "firma": hmac.new(self._llave, cuerpo.encode(), hashlib.sha256).hexdigest()}

    def verificar(self, archivo: dict) -> bool:
        from ..evidencia import canonico
        esperado = hmac.new(self._llave, canonico(archivo["movimientos"]).encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(esperado, archivo.get("firma", ""))


def conciliar(movimientos: list[dict], pagos_plataforma: list[dict]) -> dict:
    """Cada giro de la fiduciaria debe corresponder a un hito pagado en la plataforma, y al revés."""
    k = lambda m: (m["id_sismo"], m["hito"], round(m["valor"], 2))
    a, b = {k(m) for m in movimientos}, {k(p) for p in pagos_plataforma}
    return {"cuadra": a == b, "giros_sin_hito": sorted(a - b), "hitos_sin_giro": sorted(b - a)}


class RudSimulado:
    def __init__(self, seudonimos: set[str]):
        self._s = set(seudonimos)

    def existe(self, s: str) -> bool:
        return s in self._s

    def todos(self) -> set[str]:
        return set(self._s)


class UngrdSimulado:
    """Sustituto del registro de intervenciones de la UNGRD. El real exige convenio de intercambio de datos."""
    nombre = "ungrd-simulado"
    def __init__(self, intervenciones: list[dict]):
        self._i = list(intervenciones)

    def intervenciones(self, municipio_dane: str) -> list[dict]:
        return [i for i in self._i if i.get("municipio_dane") == municipio_dane]
