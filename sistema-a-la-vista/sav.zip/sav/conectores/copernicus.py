"""Catálogo de Copernicus Data Space Ecosystem (OData, consulta pública sin credenciales).

Responde qué escenas Sentinel-2 (óptico) y Sentinel-1 (radar) cubren el polígono de una obra
entre dos fechas. Descargar los píxeles sí exige una cuenta gratuita; eso lo hace un
`ProveedorDePixeles` (ver sav/satelite.py).
"""
from __future__ import annotations
from datetime import date
import httpx

URL = "https://catalogue.dataspace.copernicus.eu/odata/v1/Products"
COLECCIONES = {"SENTINEL-2": "óptico, 10 m", "SENTINEL-1": "radar, atraviesa las nubes"}


def _wkt(poligono: list[tuple[float, float]]) -> str:
    if len(poligono) < 3:
        raise ValueError("el polígono necesita al menos tres vértices")
    for lon, lat in poligono:
        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError("coordenada fuera de rango")
    anillo = list(poligono) + ([poligono[0]] if tuple(poligono[0]) != tuple(poligono[-1]) else [])
    return "POLYGON((" + ",".join(f"{lon:.6f} {lat:.6f}" for lon, lat in anillo) + "))"


def normalizar(p: dict) -> dict:
    nubes = next((a.get("Value") for a in p.get("Attributes", []) if a.get("Name") == "cloudCover"), None)
    return {"id": p["Id"], "nombre": p["Name"], "fecha": p["ContentDate"]["Start"][:10], "nubes": round(nubes, 1) if nubes is not None else None,
            "satelite": p["Name"][:3], "nivel": "L2A" if "MSIL2A" in p["Name"] else "L1C" if "MSIL1C" in p["Name"] else p["Name"].split("_")[2] if "_" in p["Name"] else ""}


class Catalogo:
    def __init__(self, cliente: httpx.Client | None = None):
        self._c = cliente or httpx.Client(timeout=40)

    def escenas(self, poligono: list[tuple[float, float]], desde: date, hasta: date, coleccion: str = "SENTINEL-2",
                nubes_max: float | None = None, limite: int = 100) -> list[dict]:
        if coleccion not in COLECCIONES:
            raise ValueError(f"colección desconocida: {coleccion}")
        if hasta < desde:
            raise ValueError("el rango de fechas está invertido")
        f = (f"Collection/Name eq '{coleccion}' and OData.CSC.Intersects(area=geography'SRID=4326;{_wkt(poligono)}') "
             f"and ContentDate/Start ge {desde.isoformat()}T00:00:00.000Z and ContentDate/Start le {hasta.isoformat()}T23:59:59.000Z")
        if coleccion == "SENTINEL-2":
            f += " and contains(Name,'MSIL2A')"
            if nubes_max is not None:
                f += f" and Attributes/OData.CSC.DoubleAttribute/any(att:att/Name eq 'cloudCover' and att/OData.CSC.DoubleAttribute/Value le {float(nubes_max):.1f})"
        else:
            f += " and contains(Name,'_GRD')"          # producto listo para comparar; RAW y SLC no sirven aquí
        r = self._c.get(URL, params={"$filter": f, "$top": min(limite, 100), "$orderby": "ContentDate/Start asc", "$expand": "Attributes"})
        r.raise_for_status()
        return [normalizar(p) for p in r.json().get("value", [])]
