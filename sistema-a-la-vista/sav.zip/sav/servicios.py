"""Operaciones del negocio. Cada una valida permisos, aplica reglas y deja huella en la bitácora."""
from __future__ import annotations
import base64, os
from datetime import date, datetime, timezone
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from . import bitacora, calendario as cal, config, contratacion, evidencia as evd, idsismo, reglas, seguridad as seg
from . import banderas as mod_banderas
from . import cifrado, satelite
from . import duplicados as mod_duplicados
from .db import Activacion, Alerta, Bandera, Bloqueo, CasoAtencion, Contrato, DocumentoOficial, Duplicado, Evidencia, Hito, Proyecto, RevisionSatelital


class Rechazo(Exception):
    """La operación no procede por una regla. Lleva la activación que lo explica."""
    def __init__(self, motivo: str, activacion: dict | None = None):
        super().__init__(motivo)
        self.motivo, self.activacion = motivo, activacion


class NoExiste(Exception):
    pass


def _tsa():
    if config.TSA_URL():
        from .sello_rfc3161 import SelladoRFC3161
        return SelladoRFC3161(config.TSA_URL(), config.TSA_CA())
    return evd.SelladoSimulado(config.LLAVE_SELLO())


def _activar(s: Session, a: reglas.Activacion, referencia: str, actor: str = "sistema", rol: str = "sistema") -> Activacion:
    fila = Activacion(regla=a.regla, referencia=referencia, accion=a.accion, responsable=a.responsable, datos=a.datos, vence=a.vence)
    s.add(fila)
    bitacora.registrar(s, referencia, f"regla_{a.regla}", actor, rol, a.como_dict())
    return fila


def _cerrar_activaciones(s: Session, referencia: str, *reglas_n: int):
    """Cuando la causa se corrige, la activación se cierra; el registro del hecho sigue en la bitácora."""
    for a in s.execute(select(Activacion).where(Activacion.referencia == referencia, Activacion.regla.in_(reglas_n), Activacion.abierta.is_(True))).scalars():
        a.abierta = False


def _hacer(s: Session, id_sismo: str, actor: str, rol: str, accion: str, datos: dict | None = None):
    """Permiso + separación de funciones + registro. Un intento bloqueado también queda en la bitácora."""
    try:
        seg.exigir_permiso(rol, accion)
        previa = seg.conflicto_de_funciones(s, id_sismo, actor, accion)
        if previa:
            raise seg.Prohibido(f"separación de funciones: {actor} ya hizo «{previa}» sobre {id_sismo} y no puede «{accion}»")
    except seg.Prohibido as e:
        bitacora.registrar(s, id_sismo, "intento_bloqueado", actor, rol, {"accion": accion, "motivo": e.motivo})
        s.commit()
        raise
    return bitacora.registrar(s, id_sismo, accion, actor, rol, datos or {})


def _obtener(s: Session, modelo, pk):
    o = s.get(modelo, pk)
    if not o:
        raise NoExiste(f"{modelo.__name__} {pk} no existe")
    return o


# ---------------------------------------------------------------- proyectos
def crear_proyecto(s: Session, ficha: dict, actor: str, rol: str) -> Proyecto:
    seg.exigir_permiso(rol, "crear_proyecto")
    a = reglas.r1_ficha(ficha)
    if a:
        _activar(s, a, f"ficha:{ficha.get('nombre', 'sin nombre')}"[:80], actor, rol).abierta = False  # la ficha se devuelve: no queda nada pendiente en la plataforma
        s.commit()
        raise Rechazo("Ficha incompleta: no entra a la agenda", a.como_dict())
    dane, sector = ficha["municipio_dane"], ficha["sector"]
    prefijo = f"SISMO26-{dane}-{sector}-"
    ultimo = s.execute(select(func.max(Proyecto.id_sismo)).where(Proyecto.id_sismo.like(prefijo + "%"))).scalar()
    ids = idsismo.construir(dane, sector, (int(ultimo[-6:]) + 1) if ultimo else 1)
    p = Proyecto(id_sismo=ids, nombre=ficha["nombre"], municipio_dane=dane, municipio=ficha.get("municipio", ""),
                 zona=ficha.get("zona", 0), sector=sector, valor=ficha["valor"], ficha=ficha, es_vivienda=sector == "VIV")
    s.add(p)
    bitacora.registrar(s, ids, "crear_proyecto", actor, rol, {"nombre": p.nombre, "valor": p.valor, "bpin": ficha["bpin"]})
    s.commit()
    return p


def registrar_contrato(s: Session, id_sismo: str, d: dict, actor: str, rol: str) -> Contrato:
    """Registra el contrato con la aprobación de la instancia que le corresponde por banda."""
    _obtener(s, Proyecto, id_sismo)
    b = contratacion.banda(d["valor_inicial"], d.get("inmuebles", False))
    if rol not in seg.APRUEBA_BANDA[b]:
        bitacora.registrar(s, id_sismo, "intento_bloqueado", actor, rol, {"accion": "aprobar", "motivo": f"banda {b}"})
        s.commit()
        raise seg.Prohibido(f"banda {b}: aprueba {contratacion.BANDAS[b]}, no «{rol}»")
    _hacer(s, id_sismo, actor, rol, "aprobar", {"banda": b, "valor": d["valor_inicial"]})
    c = Contrato(id_sismo=id_sismo, id_secop=d.get("id_secop"), publicado=d.get("publicado", False), contratista=d["contratista"],
                 representante=d.get("representante", ""), constitucion_contratista=d.get("constitucion_contratista"),
                 oferentes=d.get("oferentes", 0), valor_inicial=d["valor_inicial"], inmuebles=d.get("inmuebles", False),
                 banda=b, aprobado_por=actor, items=d.get("items", []))
    s.add(c)
    s.flush()
    for i, h in enumerate(d.get("hitos", []), start=1):
        s.add(Hito(contrato_id=c.id, numero=i, valor=h["valor"], valor_planeado=h.get("valor_planeado", 0)))
    s.commit()
    return c


def _candados_contrato(c: Contrato) -> list[reglas.Activacion]:
    return [a for a in (reglas.r2_publicacion(c.id_secop, c.publicado),
                        reglas.r4_adicion(c.valor_inicial, c.adiciones, c.adicion_aprobada)) if a]


def firmar_contrato(s: Session, contrato_id: int, actor: str, rol: str, hoy: date | None = None) -> Contrato:
    c = _obtener(s, Contrato, contrato_id)
    seg.exigir_permiso(rol, "firmar")
    cand = _candados_contrato(c)
    if cand:
        for a in cand:
            _activar(s, a, c.id_sismo, actor, rol)
        s.commit()
        raise Rechazo("Fiducoldex se abstiene de firmar", cand[0].como_dict())
    _hacer(s, c.id_sismo, actor, rol, "firmar", {"contrato": c.id, "id_secop": c.id_secop})
    c.firmado, c.firma = True, hoy or date.today()
    _cerrar_activaciones(s, c.id_sismo, 2, 4)
    s.commit()
    return c


def registrar_adicion(s: Session, contrato_id: int, valor: float, aprobada_comite: bool, actor: str, rol: str) -> Contrato:
    c = _obtener(s, Contrato, contrato_id)
    seg.exigir_permiso(rol, "registrar_adicion")
    if valor <= 0:
        raise ValueError("la adición debe ser positiva")
    c.adiciones += valor
    c.adicion_aprobada = aprobada_comite
    bitacora.registrar(s, c.id_sismo, "adicion", actor, rol, {"contrato": c.id, "valor": valor, "acumulado": c.adiciones, "aprobada_comite": aprobada_comite})
    a = reglas.r4_adicion(c.valor_inicial, c.adiciones, c.adicion_aprobada)
    if a:
        _activar(s, a, c.id_sismo)
    s.commit()
    return c


# ---------------------------------------------------------------- evidencia y pago
def cargar_evidencia(s: Session, hito_id: int, contenido_b64: str, lon: float, lat: float, capturada: datetime, actor: str, rol: str,
                     huella_dispositivo: str | None = None) -> Evidencia:
    h = _obtener(s, Hito, hito_id)
    seg.exigir_permiso(rol, "cargar_evidencia")
    try:
        contenido = base64.b64decode(contenido_b64, validate=True)
    except Exception:
        raise ValueError("el contenido no es base64 válido")
    if not contenido:
        raise ValueError("la evidencia llegó vacía")
    if capturada.tzinfo is None:
        capturada = capturada.replace(tzinfo=timezone.utc)
    hu = evd.huella(contenido)
    if huella_dispositivo and huella_dispositivo.lower() != hu:
        raise ValueError("la foto llegó distinta de como salió del teléfono: la huella no coincide")
    ya = s.execute(select(Evidencia).where(Evidencia.hito_id == h.id, Evidencia.huella == hu)).scalars().first()
    if ya:
        return ya  # reintento de sincronización: la misma foto del mismo hito no se duplica
    if h.estado not in ("pendiente", "devuelto"):
        raise Rechazo(f"El hito está {h.estado}: ya no recibe evidencia")
    proyecto = h.contrato.proyecto
    poligono = [tuple(p) for p in proyecto.ficha["poligono"]]
    tsa = _tsa()
    sello = tsa.sellar(hu)
    repetida = s.execute(select(func.count()).select_from(Evidencia).where(Evidencia.huella == hu)).scalar() > 0
    ev = Evidencia(hito_id=h.id, huella=hu, lon=lon, lat=lat, capturada=capturada, sello=sello,
                   en_geocerca=evd.dentro((lon, lat), poligono),
                   hora_coherente=evd.hora_coherente(capturada, datetime.fromisoformat(sello["ts"])), repetida=repetida)
    s.add(ev)
    carpeta = config.DIR_EVIDENCIAS()
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, hu)
    if not os.path.exists(ruta):
        with open(ruta, "wb") as f:
            f.write(contenido)
    bitacora.registrar(s, proyecto.id_sismo, "evidencia", actor, rol, {"hito": h.numero, "huella": hu, "en_geocerca": ev.en_geocerca,
                                                                    "hora_coherente": ev.hora_coherente, "repetida": repetida, "sello": sello["ts"]})
    s.commit()
    return ev


def _regla3(h: Hito) -> reglas.Activacion | None:
    fotos = h.evidencias
    buenas = [e for e in fotos if e.en_geocerca and not e.repetida]
    selladas = [e for e in fotos if e.hora_coherente and _tsa().verificar(e.huella, e.sello)]
    return reglas.r3_evidencia(h.acta_firmada, len(fotos), len(buenas), len(selladas))


def certificar_hito(s: Session, hito_id: int, valor_ganado: float, actor: str, rol: str) -> Hito:
    h = _obtener(s, Hito, hito_id)
    ids = h.contrato.id_sismo
    _hacer(s, ids, actor, rol, "certificar", {"hito": h.numero, "valor_ganado": valor_ganado})
    h.acta_firmada, h.valor_ganado = True, valor_ganado
    a = _regla3(h)
    if a:
        h.estado = "devuelto"
        _activar(s, a, ids)
        s.commit()
        raise Rechazo("Hito sin evidencia válida: vuelve al ejecutor", a.como_dict())
    h.estado = "certificado"
    _cerrar_activaciones(s, ids, 3)
    s.commit()
    return h


def estado_pago(s: Session, hito_id: int) -> dict:
    """Lo que Fiducoldex consulta antes de instruir un giro: pagable o no, y por qué."""
    h = _obtener(s, Hito, hito_id)
    c = h.contrato
    motivos = [a.como_dict() for a in _candados_contrato(c)]
    a3 = _regla3(h)
    if a3:
        motivos.append(a3.como_dict())
    confirmadas = s.execute(select(func.count()).select_from(Bandera).where(Bandera.contrato_id == c.id, Bandera.estado == "confirmada")).scalar()
    if confirmadas:
        motivos.append(reglas.r8_bandera(True).como_dict())
    if s.execute(select(func.count()).select_from(Duplicado).where(Duplicado.id_sismo == c.id_sismo, Duplicado.estado == "confirmado")).scalar():
        motivos.append({"regla": None, "nombre": "Doble financiación confirmada con la UNGRD", "accion": "No hay pago hasta que se resuelva quién financia la obra"})
    if not c.firmado:
        motivos.append({"regla": None, "nombre": "Contrato sin firmar", "accion": "No hay pago sin contrato firmado"})
    return {"hito": h.id, "id_sismo": c.id_sismo, "estado": "PAGABLE" if not motivos else "NO PAGABLE", "pagable": not motivos, "motivos": motivos}


def autorizar_pago(s: Session, hito_id: int, actor: str, rol: str, hoy: date | None = None) -> Hito:
    h = _obtener(s, Hito, hito_id)
    seg.exigir_permiso(rol, "autorizar")
    e = estado_pago(s, hito_id)
    if not e["pagable"] or h.estado != "certificado":
        bitacora.registrar(s, e["id_sismo"], "intento_bloqueado", actor, rol, {"accion": "autorizar", "motivo": "hito no pagable"})
        s.commit()
        raise Rechazo("El hito no es pagable", (e["motivos"] or [{"nombre": f"estado {h.estado}"}])[0])
    _hacer(s, e["id_sismo"], actor, rol, "autorizar", {"hito": h.numero, "valor": h.valor})
    hoy = hoy or date.today()
    h.estado, h.orden_pago, h.plazo_pago = "autorizado", hoy, cal.sumar_habiles(hoy, 5)
    s.commit()
    return h


def pagar(s: Session, hito_id: int, actor: str, rol: str, hoy: date | None = None) -> Hito:
    h = _obtener(s, Hito, hito_id)
    seg.exigir_permiso(rol, "pagar")
    e = estado_pago(s, hito_id)
    if not e["pagable"] or h.estado != "autorizado":
        bitacora.registrar(s, e["id_sismo"], "intento_bloqueado", actor, rol, {"accion": "pagar", "motivo": "sin autorización o no pagable"})
        s.commit()
        raise Rechazo("No se instruye el giro: el hito no está autorizado o no es pagable", (e["motivos"] or [{"nombre": f"estado {h.estado}"}])[0])
    _hacer(s, e["id_sismo"], actor, rol, "pagar", {"hito": h.numero, "valor": h.valor})
    h.estado, h.pagado = "pagado", hoy or date.today()
    s.commit()
    return h


# ---------------------------------------------------------------- bloqueos
def abrir_bloqueo(s: Session, id_sismo: str, descripcion: str, dueno: str, abierto: date, actor: str, rol: str) -> Bloqueo:
    seg.exigir_permiso(rol, "bloqueos")
    _obtener(s, Proyecto, id_sismo)
    b = Bloqueo(id_sismo=id_sismo, descripcion=descripcion, dueno=dueno, abierto=abierto)
    s.add(b)
    bitacora.registrar(s, id_sismo, "bloqueo_abierto", actor, rol, {"descripcion": descripcion, "dueno": dueno})
    s.commit()
    return b


def cerrar_bloqueo(s: Session, bloqueo_id: int, hoy: date, actor: str, rol: str) -> Bloqueo:
    seg.exigir_permiso(rol, "bloqueos")
    b = _obtener(s, Bloqueo, bloqueo_id)
    b.cerrado = hoy
    bitacora.registrar(s, b.id_sismo, "bloqueo_cerrado", actor, rol, {"bloqueo": b.id})
    s.commit()
    return b


def corrida_bloqueos(s: Session, hoy: date) -> list[dict]:
    """Regla 7: cada día hábil sube de nivel lo que venció."""
    out = []
    for b in s.execute(select(Bloqueo).where(Bloqueo.cerrado.is_(None))).scalars():
        a = reglas.r7_bloqueo(b.abierto, hoy, b.nivel)
        if a and (a.datos["nivel"] > b.nivel or (a.datos["vencido"] and not b.vencido)):
            b.nivel, b.vencido = a.datos["nivel"], a.datos["vencido"]
            _activar(s, a, b.id_sismo)
            out.append({"bloqueo": b.id, **a.datos})
    s.commit()
    return out


# ---------------------------------------------------------------- banderas
def corrida_banderas(s: Session, procesos: list[dict] = (), apoyos: list[dict] = (), rud: set[str] = frozenset()) -> list[Bandera]:
    contratos, pagos = [], []
    for c in s.execute(select(Contrato)).scalars():
        contratos.append({"id": f"contrato:{c.id}", "valor_inicial": c.valor_inicial, "adiciones": c.adiciones, "items": c.items,
                          "constitucion_contratista": c.constitucion_contratista, "firma": c.firma, "zona": c.proyecto.zona,
                          "contratista": c.contratista, "_pk": c.id})
        for h in c.hitos:
            if h.estado == "pagado":
                pagos.append({"id": f"contrato:{c.id}", "acta": h.acta_firmada})
    pk = {c["id"]: c["_pk"] for c in contratos}
    nuevas = []
    for b in mod_banderas.calcular(list(procesos), contratos, pagos, list(apoyos), rud):
        existe = s.execute(select(Bandera).where(Bandera.bandera == b["bandera"], Bandera.referencia == b["referencia"], Bandera.dato == b["dato"])).first()
        if existe:
            continue
        fila = Bandera(bandera=b["bandera"], nombre=b["nombre"], referencia=b["referencia"], dato=b["dato"], decide=b["decide"], contrato_id=pk.get(b["referencia"]))
        s.add(fila)
        nuevas.append(fila)
        bitacora.registrar(s, b["referencia"], "bandera_detectada", "sistema", "sistema", b)
    s.commit()
    return nuevas


def decidir_bandera(s: Session, bandera_id: int, confirmar: bool, motivo: str, actor: str, rol: str) -> Bandera:
    seg.exigir_permiso(rol, "decidir_bandera")
    b = _obtener(s, Bandera, bandera_id)
    if b.estado != "revision":
        raise Rechazo("La bandera ya fue decidida")
    if not motivo.strip():
        raise ValueError("toda decisión lleva motivo escrito")
    if b.bandera == 9 and confirmar:
        # una bandera de beneficiario nunca retiene la ayuda: va a verificación de la UNGRD
        b.estado, b.motivo, b.decidida_por = "confirmada", motivo, actor
        bitacora.registrar(s, b.referencia, "bandera_a_ungrd", actor, rol, {"bandera": b.id, "motivo": motivo})
        s.commit()
        return b
    b.estado, b.motivo, b.decidida_por = ("confirmada" if confirmar else "descartada"), motivo, actor
    bitacora.registrar(s, b.referencia, "bandera_" + b.estado, actor, rol, {"bandera": b.id, "motivo": motivo})
    if confirmar:
        _activar(s, reglas.r8_bandera(True), b.referencia, actor, rol)
    s.commit()
    return b


# ---------------------------------------------------------------- alertas
def radicar_alerta(s: Session, tipo: str, texto: str, municipio: str, recibida: date) -> Alerta:
    if len(texto.strip()) < 10:
        raise ValueError("describa la alerta con al menos diez caracteres")
    vence = reglas.plazo_alerta(tipo, recibida)
    a = Alerta(tipo=tipo, texto=texto.strip(), municipio=municipio, recibida=recibida, vence=vence, estado="en_plazo" if vence else "trasladada")
    s.add(a)
    s.flush()
    bitacora.registrar(s, f"alerta:{a.id}", "alerta_radicada", "publico", "publico", {"tipo": tipo, "vence": vence})
    s.commit()
    return a


def responder_alerta(s: Session, alerta_id: int, respuesta: str, evidencia: str, actor: str, rol: str) -> Alerta:
    seg.exigir_permiso(rol, "responder_alerta")
    a = _obtener(s, Alerta, alerta_id)
    if not evidencia.strip():
        raise Rechazo("Una respuesta sin evidencia no cierra una alerta")
    a.respuesta, a.evidencia_respuesta, a.estado = respuesta, evidencia, "cerrada"
    bitacora.registrar(s, f"alerta:{a.id}", "alerta_cerrada", actor, rol, {"evidencia": evidencia})
    s.commit()
    return a


def corrida_alertas(s: Session, hoy: date) -> list[int]:
    out = []
    for a in s.execute(select(Alerta).where(Alerta.estado == "en_plazo")).scalars():
        act = reglas.r9_alerta(a.tipo, a.recibida, hoy, False)
        if act:
            a.estado = "sin_respuesta"
            _activar(s, act, f"alerta:{a.id}")
            out.append(a.id)
    s.commit()
    return out


# ---------------------------------------------------------------- corte mensual
def avance(c: Contrato) -> dict:
    vp = sum(h.valor_planeado for h in c.hitos)
    vg = sum(h.valor_ganado for h in c.hitos)
    cr = sum(h.valor for h in c.hitos if h.estado == "pagado")
    return {"vp": vp, "vg": vg, "cr": cr, "spi": round(reglas.spi(vg, vp), 3), "cpi": round(reglas.cpi(vg, cr), 3)}


def corte_mensual(s: Session, corte: date) -> list[dict]:
    """Reglas 5 y 6 por contrato firmado con valor planeado."""
    out = []
    for c in s.execute(select(Contrato).where(Contrato.firmado.is_(True))).scalars():
        av = avance(c)
        if not av["vp"]:
            continue
        a = reglas.r5_r6_avance(av["vg"], av["vp"], corte, c.spi_anterior)
        if a:
            _activar(s, a, c.id_sismo)
            out.append({"id_sismo": c.id_sismo, "regla": a.regla, **a.datos})
        c.spi_anterior = av["spi"]
    s.commit()
    return out


def conciliar_secop(s: Session, con) -> dict:
    """Marca qué contratos están publicados en SECOP II. Un contrato que deja de estarlo vuelve a quedar sin pago (regla 2)."""
    cambios, errores = [], []
    for c in s.execute(select(Contrato).where(Contrato.id_secop.is_not(None))).scalars():
        try:
            pub = con.esta_publicado(c.id_secop)
        except Exception as e:
            errores.append({"contrato": c.id, "error": type(e).__name__})
            continue
        if pub != c.publicado:
            c.publicado = pub
            bitacora.registrar(s, c.id_sismo, "conciliacion_secop", "sistema", "sistema", {"contrato": c.id, "id_secop": c.id_secop, "publicado": pub})
            cambios.append({"contrato": c.id, "id_secop": c.id_secop, "publicado": pub})
    s.commit()
    return {"cambios": cambios, "errores": errores}


def corrida_diaria(s: Session, fecha: date) -> dict:
    """Lo que debe correr cada noche: bloqueos (regla 7), alertas (regla 9), banderas y sello de la bitácora."""
    r = {"bloqueos": corrida_bloqueos(s, fecha), "alertas_sin_respuesta": corrida_alertas(s, fecha), "banderas_nuevas": len(corrida_banderas(s))}
    sello = bitacora.sellar(s, _tsa())
    s.commit()
    r["sello"] = {"seq": sello.seq, "huella": sello.huella} if sello else None
    return r


# ---------------------------------------------------------------- satélite
def revision_satelital(s: Session, desde: date, hasta: date, catalogo, pixeles=None) -> list[dict]:
    """Revisa cada obra de más de 10.000 SMMLV. «Sin cambio» abre una alerta que pide visita; no toca ningún hito."""
    out = []
    for p in s.execute(select(Proyecto)).scalars():
        if not satelite.requiere_satelite(p.valor):
            continue
        poligono = [tuple(x) for x in p.ficha["poligono"]]
        try:
            escenas = catalogo.escenas(poligono, desde, hasta, "SENTINEL-2", nubes_max=60)
            fuente = "SENTINEL-2"
            if len(escenas) < 2:
                escenas, fuente = catalogo.escenas(poligono, desde, hasta, "SENTINEL-1"), "SENTINEL-1"
            r = {**satelite.revisar(escenas, poligono, pixeles), "fuente": fuente}
        except Exception as e:
            r = {"estado": "error", "detalle": f"No fue posible consultar el catálogo ({type(e).__name__}); se reintenta en la siguiente corrida."}
        r.pop("escenas", None)
        s.add(RevisionSatelital(id_sismo=p.id_sismo, desde=desde, hasta=hasta, estado=r["estado"], resultado=r))
        bitacora.registrar(s, p.id_sismo, "revision_satelital", "sistema", "sistema", {"estado": r["estado"], "desde": desde, "hasta": hasta})
        if r["estado"] == "sin_cambio":
            a = Alerta(tipo="anomalia", texto=f"Satélite: sin cambio visible en el polígono de {p.id_sismo} entre {desde} y {hasta}. Se pide visita de la interventoría.",
                       municipio=p.municipio, recibida=hasta, vence=reglas.plazo_alerta("anomalia", hasta))
            s.add(a)
        out.append({"id_sismo": p.id_sismo, **r})
    s.commit()
    return out


# ---------------------------------------------------------------- duplicados con la UNGRD
def corrida_duplicados(s: Session, registro) -> dict:
    """Compara cada proyecto con las intervenciones de la UNGRD en su municipio. Solo registra coincidencias nuevas."""
    nuevos, errores, por_municipio = [], [], {}
    for p in s.execute(select(Proyecto)).scalars():
        if p.municipio_dane not in por_municipio:
            try:
                por_municipio[p.municipio_dane] = list(registro.intervenciones(p.municipio_dane))
            except Exception as e:
                por_municipio[p.municipio_dane] = None
                errores.append({"municipio_dane": p.municipio_dane, "error": type(e).__name__})
        for i in por_municipio[p.municipio_dane] or []:
            r = mod_duplicados.comparar({"nombre": p.nombre, "municipio_dane": p.municipio_dane, "sector": p.sector, "poligono": p.ficha.get("poligono")}, i)
            if not r or s.execute(select(Duplicado.id).where(Duplicado.id_sismo == p.id_sismo, Duplicado.id_ungrd == r["id_ungrd"])).first():
                continue
            d = Duplicado(id_sismo=p.id_sismo, **r)
            s.add(d); s.flush(); nuevos.append(d.id)
            bitacora.registrar(s, p.id_sismo, "duplicado_detectado", "sistema", "sistema", {"id_ungrd": r["id_ungrd"], "nivel": r["nivel"], "motivos": r["motivos"]})
    s.commit()
    return {"nuevos": nuevos, "errores": errores}


def decidir_duplicado(s: Session, dup_id: int, confirmar: bool, motivo: str, actor: str, rol: str) -> Duplicado:
    seg.exigir_permiso(rol, "decidir_duplicado")
    d = _obtener(s, Duplicado, dup_id)
    if d.estado != "revision":
        raise Rechazo("La coincidencia ya fue decidida")
    if len(motivo.strip()) < 5:
        raise ValueError("toda decisión lleva motivo escrito")
    d.estado, d.motivo, d.decidido_por = ("confirmado" if confirmar else "descartado"), motivo.strip(), actor
    bitacora.registrar(s, d.id_sismo, "duplicado_" + d.estado, actor, rol, {"id_ungrd": d.id_ungrd, "motivo": d.motivo})
    s.commit()
    return d


# ---------------------------------------------------------------- atención: documentos oficiales y casos
def publicar_documento(s: Session, titulo: str, texto: str, actor: str, rol: str) -> DocumentoOficial:
    seg.exigir_permiso(rol, "documentos")
    titulo = " ".join(titulo.split())
    d = s.execute(select(DocumentoOficial).where(DocumentoOficial.titulo == titulo)).scalar()
    if d:
        d.texto, d.vigente, d.publicado_por, d.actualizado = texto.strip(), True, actor, datetime.now(timezone.utc)
    else:
        d = DocumentoOficial(titulo=titulo, texto=texto.strip(), publicado_por=actor); s.add(d)
    bitacora.registrar(s, "documentos", "documento_publicado", actor, rol, {"titulo": titulo, "huella": evd.huella(texto.strip().encode())})
    s.commit()
    return d


def retirar_documento(s: Session, doc_id: int, actor: str, rol: str) -> DocumentoOficial:
    seg.exigir_permiso(rol, "documentos")
    d = _obtener(s, DocumentoOficial, doc_id)
    d.vigente = False
    bitacora.registrar(s, "documentos", "documento_retirado", actor, rol, {"titulo": d.titulo})
    s.commit()
    return d


def cerrar_caso(s: Session, caso_id: int, respuesta: str, actor: str, rol: str, emisor=None, llamada_hecha: bool = False) -> CasoAtencion:
    """La respuesta sale por el mismo canal. Entregada la respuesta, el número se borra del caso."""
    seg.exigir_permiso(rol, "atender_casos")
    k = _obtener(s, CasoAtencion, caso_id)
    if k.estado != "abierto":
        raise Rechazo("El caso ya está cerrado")
    if len(respuesta.strip()) < 10:
        raise ValueError("la respuesta debe tener al menos diez caracteres")
    k.respuesta, k.atendido_por, k.estado = respuesta.strip(), actor, "cerrado"
    if k.canal == "whatsapp" and emisor is not None:
        k.entregada = bool(emisor.enviar(cifrado.descifrar(k.numero), f"Respuesta a su caso número {k.id}: {k.respuesta}"))
    if k.canal == "voz" and llamada_hecha:
        k.entregada = True
    if k.entregada:
        k.numero = ""
    bitacora.registrar(s, f"caso:{k.id}", "caso_cerrado", actor, rol, {"entregada": k.entregada})
    s.commit()
    return k


# ---------------------------------------------------------------- lectura
def resumen_publico(s: Session) -> dict:
    proyectos = s.execute(select(func.count()).select_from(Proyecto)).scalar()
    contratado = s.execute(select(func.coalesce(func.sum(Contrato.valor_inicial + Contrato.adiciones), 0)).where(Contrato.firmado.is_(True))).scalar()
    pagado = s.execute(select(func.coalesce(func.sum(Hito.valor), 0)).where(Hito.estado == "pagado")).scalar()
    pagados = s.execute(select(Hito).where(Hito.estado == "pagado")).scalars().all()
    con_evidencia = sum(1 for h in pagados if h.acta_firmada and h.evidencias)
    return {"proyectos": proyectos, "contratado": contratado, "pagado": pagado,
            "pagos_con_evidencia": (con_evidencia / len(pagados)) if pagados else None,
            "alertas_abiertas": s.execute(select(func.count()).select_from(Alerta).where(Alerta.estado.in_(("en_plazo", "sin_respuesta")))).scalar(),
            "alertas_sin_respuesta": s.execute(select(func.count()).select_from(Alerta).where(Alerta.estado == "sin_respuesta")).scalar(),
            "reglas_abiertas": s.execute(select(func.count()).select_from(Activacion).where(Activacion.abierta.is_(True))).scalar(),
            "bitacora": bitacora.verificar(s)}


def proyecto_publico(p: Proyecto) -> dict:
    """Lo que ve cualquier persona. Las viviendas se publican sin coordenadas (Ley 1581 de 2012)."""
    d = {"id_sismo": p.id_sismo, "nombre": p.nombre, "municipio": p.municipio, "municipio_dane": p.municipio_dane, "zona": p.zona,
         "sector": idsismo.SECTORES[p.sector], "valor": p.valor,
         "contratos": [{"id": c.id, "id_secop": c.id_secop, "contratista": c.contratista, "valor": c.valor_inicial + c.adiciones,
                        "banda": c.banda, "firmado": c.firmado, "avance": avance(c),
                        "hitos": [{"numero": h.numero, "valor": h.valor, "estado": h.estado, "evidencias": len(h.evidencias),
                                   "huellas": [e.huella for e in h.evidencias]} for h in c.hitos]} for c in p.contratos]}
    if not p.es_vivienda:
        d["poligono"] = p.ficha.get("poligono")
    return d
