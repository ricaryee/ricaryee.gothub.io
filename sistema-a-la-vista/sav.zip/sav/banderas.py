"""Las nueve banderas rojas de la sección 10.4.

Una bandera abre una verificación humana; por sí sola no retiene nada.
Entrada: procesos y contratos ya normalizados (ver conectores.secop2).
"""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import date
from .reglas import U, Umbrales

BANDERAS = {
    1: "Un solo oferente", 2: "Plazo menor al mínimo", 3: "Adiciones de más del 30 %",
    4: "Contratista nuevo", 5: "Mismo representante o beneficiario final",
    6: "Precio más de 15 % sobre la referencia", 7: "Concentración por zona",
    8: "Pago sin acta", 9: "Beneficiario repetido o ajeno al RUD",
}
DECIDE = {6: "Comité de contratación", 9: "UNGRD"}


def _b(n, ref, dato):
    return {"bandera": n, "nombre": BANDERAS[n], "referencia": ref, "dato": dato, "decide": DECIDE.get(n, "Control interno")}


def calcular(procesos: list[dict], contratos: list[dict], pagos: list[dict] = (), apoyos: list[dict] = (),
             rud: set[str] = frozenset(), plazo_minimo_dias: int = 5, meses_contratista_nuevo: int = 6,
             concentracion_max: float = 0.40, u: Umbrales = U) -> list[dict]:
    out = []
    for p in procesos:
        if p.get("adjudicado") and p.get("oferentes") == 1 and p.get("competitivo", True):
            out.append(_b(1, p["id"], "un solo oferente en un proceso competitivo"))
        if p.get("dias_para_ofertar") is not None and p["dias_para_ofertar"] < plazo_minimo_dias:
            out.append(_b(2, p["id"], f"{p['dias_para_ofertar']} días para ofertar; mínimo {plazo_minimo_dias}"))
        reps = Counter(o["representante"] for o in p.get("ofertas", []) if o.get("representante"))
        for rep, n in reps.items():
            if n > 1:
                out.append(_b(5, p["id"], f"{n} oferentes comparten representante legal"))
    por_zona = defaultdict(Counter)
    for c in contratos:
        if c.get("valor_inicial") and c.get("adiciones", 0) / c["valor_inicial"] > u.adicion_comite:
            out.append(_b(3, c["id"], f"adiciones del {c['adiciones'] / c['valor_inicial']:.0%}"))
        fc, ff = c.get("constitucion_contratista"), c.get("firma")
        if isinstance(fc, date) and isinstance(ff, date) and (ff - fc).days < meses_contratista_nuevo * 30:
            out.append(_b(4, c["id"], f"contratista constituido {(ff - fc).days} días antes de la firma"))
        for it in c.get("items", []):
            if it["referencia"] > 0 and it["ofertado"] / it["referencia"] > u.precio_max:
                out.append(_b(6, c["id"], f"{it['item']}: {it['ofertado'] / it['referencia']:.3f} veces la referencia"))
        if c.get("zona") is not None:
            por_zona[c["zona"]][c.get("contratista")] += c.get("valor_inicial", 0)
    for zona, cnt in por_zona.items():
        total = sum(cnt.values())
        if total and len(cnt) > 1:
            quien, v = cnt.most_common(1)[0]
            if v / total > concentracion_max:
                out.append(_b(7, f"zona {zona}", f"un contratista concentra el {v / total:.0%} del valor"))
    for pg in pagos:
        if not pg.get("acta"):
            out.append(_b(8, pg["id"], "pago sin acta de interventoría asociada"))
    vistos = Counter(a["seudonimo"] for a in apoyos)
    for a in apoyos:
        if vistos[a["seudonimo"]] > 1 and a.get("incompatible"):
            out.append(_b(9, a["seudonimo"], "el mismo seudónimo recibe apoyos incompatibles"))
        elif rud and a["seudonimo"] not in rud:
            out.append(_b(9, a["seudonimo"], "el seudónimo no está en el RUD"))
    # sin duplicados exactos
    uniq, vistos2 = [], set()
    for b in out:
        k = (b["bandera"], b["referencia"], b["dato"])
        if k not in vistos2:
            vistos2.add(k); uniq.append(b)
    return uniq
