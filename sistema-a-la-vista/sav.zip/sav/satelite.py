"""Segundo testigo satelital para obras grandes, demoliciones y movimientos de tierra.

Tres piezas:
  1. Qué obras se revisan: las de más de 10.000 SMMLV.
  2. Qué escenas hay: catálogo real de Copernicus (sav/conectores/copernicus.py).
  3. Si hubo cambio dentro del polígono: `detectar_cambio`, sobre dos matrices de reflectancia.

Lo que NO hace: a 10 metros por píxel no se ve el avance de una vivienda, y un resultado
«sin cambio» nunca rechaza un hito: pide una visita. Decide el interventor.
"""
from __future__ import annotations
from typing import Protocol
from . import contratacion

UMBRAL_SMMLV = 10_000


def requiere_satelite(valor_pesos: float) -> bool:
    return contratacion.en_smmlv(valor_pesos) > UMBRAL_SMMLV


def _media(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else 0.0


def detectar_cambio(antes: list[list[float]], despues: list[list[float]], mascara: list[list[bool]],
                    umbral: float = 0.08, minimo_pixeles: int = 4) -> dict:
    """Compara el cambio medio dentro del polígono con el de su entorno.

    antes/despues: matrices del mismo tamaño (reflectancia o retrodispersión, 0 a 1).
    mascara: True para los píxeles dentro del polígono de la obra.
    Restar el cambio del entorno descuenta lo que afecta a toda la escena (luz, humedad, estación).
    """
    if not (len(antes) == len(despues) == len(mascara)) or any(len(a) != len(d) or len(a) != len(m) for a, d, m in zip(antes, despues, mascara)):
        raise ValueError("las matrices no tienen el mismo tamaño")
    dentro, fuera = [], []
    for fa, fd, fm in zip(antes, despues, mascara):
        for a, d, m in zip(fa, fd, fm):
            (dentro if m else fuera).append(abs(d - a))
    if len(dentro) < minimo_pixeles:
        return {"concluyente": False, "cambio": None, "motivo": f"el polígono cubre {len(dentro)} píxeles; mínimo {minimo_pixeles}", "pixeles": len(dentro)}
    indice = _media(dentro) - _media(fuera)
    return {"concluyente": True, "cambio": indice > umbral, "indice": round(indice, 4), "umbral": umbral, "pixeles": len(dentro),
            "cambio_dentro": round(_media(dentro), 4), "cambio_entorno": round(_media(fuera), 4)}


def mascara_de(poligono, lon0: float, lat0: float, paso: float, filas: int, columnas: int) -> list[list[bool]]:
    """Rasteriza el polígono sobre una malla regular (centro de cada píxel)."""
    from .evidencia import dentro
    return [[dentro((lon0 + (c + 0.5) * paso, lat0 - (f + 0.5) * paso), poligono) for c in range(columnas)] for f in range(filas)]


class ProveedorDePixeles(Protocol):
    """Entrega la ventana de píxeles de una escena sobre el polígono. El real usa la cuenta de Copernicus."""
    nombre: str
    def ventana(self, escena_id: str, poligono) -> tuple[list[list[float]], list[list[bool]]]: ...


def revisar(escenas: list[dict], poligono, pixeles: ProveedorDePixeles | None = None) -> dict:
    """Arma la revisión con la primera y la última escena del periodo."""
    if len(escenas) < 2:
        return {"estado": "sin_imagenes", "detalle": "No hay dos escenas utilizables en el periodo; se intenta con radar o se amplía el rango.", "escenas": escenas}
    a, d = escenas[0], escenas[-1]
    base = {"antes": a, "despues": d, "escenas_disponibles": len(escenas)}
    if pixeles is None:
        return {**base, "estado": "escenas_listas", "detalle": "Hay imágenes para comparar. Falta el proveedor de píxeles (cuenta de Copernicus) para calcular el cambio."}
    ma, mascara = pixeles.ventana(a["id"], poligono)
    md, _ = pixeles.ventana(d["id"], poligono)
    r = detectar_cambio(ma, md, mascara)
    if not r["concluyente"]:
        return {**base, "estado": "no_concluyente", "detalle": r["motivo"], "analisis": r, "proveedor": pixeles.nombre}
    return {**base, "estado": "cambio_detectado" if r["cambio"] else "sin_cambio", "analisis": r, "proveedor": pixeles.nombre,
            "detalle": "Cambio dentro del polígono, coherente con obra en curso." if r["cambio"] else "No se observa cambio dentro del polígono: se pide visita. Esto no rechaza ningún hito."}
