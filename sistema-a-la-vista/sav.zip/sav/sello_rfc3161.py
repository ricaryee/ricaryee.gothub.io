"""Sello de tiempo RFC 3161 contra una autoridad de sellado (TSA).

Misma interfaz que el sustituto local: sellar(huella) y verificar(huella, sello).
  - sellar: envía la huella SHA-256 (nunca el documento) y guarda la respuesta completa de la autoridad.
  - verificar: comprueba que el sello corresponde a esa huella y, si hay archivo de certificados raíz
    (SAV_TSA_CA), valida la firma y la cadena de la autoridad con OpenSSL. Sin ese archivo solo se
    comprueba la correspondencia, y eso no basta como prueba: en producción SAV_TSA_CA es obligatorio.
"""
from __future__ import annotations
import base64, os, secrets, subprocess, tempfile
from urllib.parse import urlparse
import httpx
from asn1crypto import tsp


class SelloRechazado(Exception):
    pass


def _info(respuesta: bytes) -> dict:
    r = tsp.TimeStampResp.load(respuesta)
    estado = r["status"]["status"].native
    if estado not in ("granted", "granted_with_mods"):
        raise SelloRechazado(f"la autoridad no concedió el sello: {estado}")
    t = r["time_stamp_token"]["content"]["encap_content_info"]["content"].parsed
    return {"huella": t["message_imprint"]["hashed_message"].native.hex(), "algoritmo": t["message_imprint"]["hash_algorithm"]["algorithm"].native,
            "ts": t["gen_time"].native, "nonce": t["nonce"].native, "serie": t["serial_number"].native}


class SelladoRFC3161:
    def __init__(self, url: str, ca: str | None = None, cliente: httpx.Client | None = None):
        self._url, self._ca, self._c = url, ca or None, cliente or httpx.Client(timeout=20)
        self.nombre = "rfc3161:" + (urlparse(url).hostname or url)

    def sellar(self, huella_hex: str) -> dict:
        nonce = secrets.randbits(63)
        pedido = tsp.TimeStampReq({"version": 1, "message_imprint": {"hash_algorithm": {"algorithm": "sha256"}, "hashed_message": bytes.fromhex(huella_hex)},
                                   "nonce": nonce, "cert_req": True}).dump()
        r = self._c.post(self._url, content=pedido, headers={"Content-Type": "application/timestamp-query"})
        r.raise_for_status()
        i = _info(r.content)
        if i["huella"] != huella_hex.lower() or i["algoritmo"] != "sha256" or i["nonce"] != nonce:
            raise SelloRechazado("la respuesta de la autoridad no corresponde a lo pedido")
        return {"autoridad": self.nombre, "tipo": "rfc3161", "ts": i["ts"].isoformat(), "serie": str(i["serie"]), "token": base64.b64encode(r.content).decode()}

    def verificar(self, huella_hex: str, sello: dict) -> bool:
        if sello.get("tipo") != "rfc3161" or not sello.get("token"):
            return False
        try:
            crudo = base64.b64decode(sello["token"], validate=True)
            i = _info(crudo)
        except Exception:
            return False
        if i["huella"] != huella_hex.lower() or i["algoritmo"] != "sha256" or i["ts"].isoformat() != sello.get("ts"):
            return False
        if not self._ca:
            return True
        with tempfile.NamedTemporaryFile(suffix=".tsr", delete=False) as f:
            f.write(crudo)
        try:
            p = subprocess.run(["openssl", "ts", "-verify", "-digest", huella_hex.lower(), "-in", f.name, "-CAfile", self._ca],
                               capture_output=True, text=True, timeout=20)
            return p.returncode == 0 and "Verification: OK" in p.stdout
        except (OSError, subprocess.SubprocessError):
            return False
        finally:
            os.unlink(f.name)
