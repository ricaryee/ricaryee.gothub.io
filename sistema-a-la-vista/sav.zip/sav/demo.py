"""Carga un recorrido de demostración con datos FICTICIOS: python -m sav.demo"""
import base64
from datetime import date, datetime, timezone
from . import servicios as sv
from .db import crear_esquema, crear_motor, fabrica

UNGRD_DEMO = [{"id": "UNGRD-DEMO-0042", "nombre": "[DEMO] Reforzamiento viviendas Pereira", "municipio_dane": "66001", "sector": "VIV", "lon": -75.6951, "lat": 4.8049},
              {"id": "UNGRD-DEMO-0077", "nombre": "[DEMO] Puente vehicular vereda La Bella", "municipio_dane": "66001", "sector": "INS", "lon": -75.62, "lat": 4.75}]
POL = [(-75.70, 4.80), (-75.69, 4.80), (-75.69, 4.81), (-75.70, 4.81)]


def cargar(motor=None):
    motor = motor or crear_motor()
    crear_esquema(motor)
    with fabrica(motor)() as s:
        f = dict(nombre="[DEMO] Reforzamiento de 48 viviendas", municipio_dane="66001", municipio="Pereira", zona=3, sector="VIV",
                 valor=4_320_000_000, bpin="DEMO-0001", admisibilidad="Demostración", poligono=POL, cronograma=[{"semana": 20}])
        p = sv.crear_proyecto(s, f, "demo.ventanilla", "ventanilla")
        c = sv.registrar_contrato(s, p.id_sismo, dict(id_secop="CO1.PCCNTR.DEMO", publicado=True, contratista="[DEMO] Constructora Ejemplo S.A.S.",
                                                     oferentes=4, valor_inicial=4_320_000_000,
                                                     hitos=[{"valor": 864_000_000, "valor_planeado": 4000}, {"valor": 864_000_000}]), "demo.comite", "comite")
        sv.firmar_contrato(s, c.id, "demo.fiduciaria", "fiducoldex")
        h = c.hitos[0]
        for n in range(3):
            sv.cargar_evidencia(s, h.id, base64.b64encode(f"demo-{n}".encode()).decode(), -75.695, 4.805, datetime.now(timezone.utc), "demo.interventor", "interventoria")
        sv.certificar_hito(s, h.id, 3400, "demo.interventor", "interventoria")
        sv.autorizar_pago(s, h.id, "demo.gerente", "gerente")
        sv.pagar(s, h.id, "demo.fiduciaria", "fiducoldex")
        sv.abrir_bloqueo(s, p.id_sismo, "[DEMO] Licencia pendiente", "Entidad ejemplo", date.today(), "demo.cumplimiento", "cumplimiento")
        sv.radicar_alerta(s, "riesgo", "[DEMO] Oferente único repetido en dos procesos", "Pereira", date.today())
        sv.publicar_documento(s, "[DEMO] Guía del subsidio de arriendo", "[DEMO] Texto ficticio. El subsidio de arriendo se entrega por seis meses a los hogares "
                              "inscritos en el registro de damnificados. Se paga cada mes a la cuenta que el hogar registró.", "demo.atencion", "atencion")
        sv.publicar_documento(s, "[DEMO] Cómo leer la valla de una obra", "[DEMO] Texto ficticio. Cada obra tiene una valla con su número de proyecto, que empieza por SISMO26. "
                              "Con ese número cualquier persona puede ver en el portal cuánto se contrató, cuánto se ha pagado y las fotos de cada pago.", "demo.atencion", "atencion")
        return p.id_sismo


def _pol(lon, lat, d=0.006):
    return [(lon, lat), (lon + d, lat), (lon + d, lat + d), (lon, lat + d)]


def cargar_amplia(motor=None):
    """Recorrido de demostración más completo, para la versión pública: cinco obras en distintos estados. Todo es FICTICIO."""
    from .canales import atender
    from .conectores.simuladores import UngrdSimulado
    motor = motor or crear_motor()
    primero = cargar(motor)
    hoy, ahora = date.today(), datetime.now(timezone.utc)
    foto = lambda n: base64.b64encode(f"demo-amplia-{n}".encode()).decode()
    with fabrica(motor)() as s:
        def obra(nombre, dane, municipio, sector, valor, lon, lat, aprueba, oferentes=4, publicado=True, hitos=2, secop="DEMO"):
            p = sv.crear_proyecto(s, dict(nombre=nombre, municipio_dane=dane, municipio=municipio, zona=3, sector=sector, valor=valor, bpin="DEMO-" + dane,
                                          admisibilidad="Demostración", poligono=_pol(lon, lat), cronograma=[{"semana": 20}]), "demo.ventanilla", "ventanilla")
            c = sv.registrar_contrato(s, p.id_sismo, dict(id_secop=f"CO1.PCCNTR.{secop}{dane}", publicado=publicado, contratista=f"[DEMO] Consorcio {municipio} 2026",
                                                         oferentes=oferentes, valor_inicial=valor, hitos=[{"valor": valor / hitos / 2, "valor_planeado": 4000}] + [{"valor": valor / hitos / 2}] * (hitos - 1)),
                                      "demo." + aprueba, aprueba)
            return p, c

        # 2. Colegio: hito certificado, listo para que el gerente autorice el pago
        p, c = obra("[DEMO] Reconstrucción del colegio Santa Sofía", "66170", "Dosquebradas", "INS", 9_800_000_000, -75.672, 4.836, "comite")
        sv.firmar_contrato(s, c.id, "demo.fiduciaria", "fiducoldex")
        for n in range(2):
            sv.cargar_evidencia(s, c.hitos[0].id, foto(f"colegio-{n}"), -75.669, 4.839, ahora, "demo.interventora", "interventoria")
        sv.certificar_hito(s, c.hitos[0].id, 3900, "demo.interventora", "interventoria")

        # 3. Acueducto: obra grande (aprueba el Consejo, la revisa el satélite); la foto llegó desde fuera de la obra y el hito se devolvió
        p, c = obra("[DEMO] Bocatoma y red de acueducto La Florida", "63001", "Armenia", "AEV", 21_000_000_000, -75.681, 4.534, "consejo", hitos=3)
        sv.firmar_contrato(s, c.id, "demo.fiduciaria", "fiducoldex")
        sv.cargar_evidencia(s, c.hitos[0].id, foto("acueducto"), -75.60, 4.60, ahora, "demo.interventor2", "interventoria")
        try:
            sv.certificar_hito(s, c.hitos[0].id, 1500, "demo.interventor2", "interventoria")
        except sv.Rechazo:
            pass
        sv.radicar_alerta(s, "anomalia", "[DEMO] Vecinos reportan que la maquinaria lleva dos semanas sin moverse", "Armenia", hoy)

        # 4. Puente: el contrato no aparece publicado en SECOP II, así que la fiduciaria no pudo firmarlo
        p, c = obra("[DEMO] Puente vehicular sobre la quebrada El Rosario", "17001", "Manizales", "REC", 1_200_000_000, -75.512, 5.066, "gerente", oferentes=1, publicado=False)
        try:
            sv.firmar_contrato(s, c.id, "demo.fiduciaria", "fiducoldex")
        except sv.Rechazo:
            pass

        # 5. Viviendas rurales: contrato firmado, con un trámite trabado que ya tiene dueño
        p, c = obra("[DEMO] Reparación de 120 viviendas rurales", "76147", "Cartago", "VIV", 2_600_000_000, -75.912, 4.747, "comite")
        sv.firmar_contrato(s, c.id, "demo.fiduciaria", "fiducoldex")
        sv.abrir_bloqueo(s, p.id_sismo, "[DEMO] Falta el concepto de la autoridad ambiental", "Corporación ambiental (ejemplo)", hoy, "demo.cumplimiento", "cumplimiento")

        sv.corrida_banderas(s)
        sv.corrida_duplicados(s, UngrdSimulado(UNGRD_DEMO))
        atender(s, "whatsapp", "573000000000", "Quiero poner una queja: en mi vereda no han empezado la obra", "demo-1")
    return primero


if __name__ == "__main__":
    print("Proyecto de demostración:", cargar())
