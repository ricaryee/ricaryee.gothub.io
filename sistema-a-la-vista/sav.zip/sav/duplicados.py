"""Cruce de duplicados: ¿este proyecto del Fondo ya lo está pagando la UNGRD?

Compara cada proyecto con las intervenciones que la UNGRD registra en el mismo municipio.
Tres señales: cercanía en el terreno, mismo sector y parecido del nombre. El resultado es una
coincidencia para revisar, nunca una decisión: la confirma o la descarta una persona con motivo escrito.
"""
from __future__ import annotations
import math, re, unicodedata

RADIO_M = 300          # dos obras a menos de 300 m se consideran el mismo sitio
PARECIDO = 0.6         # proporción de palabras compartidas a partir de la cual dos nombres se parecen
_VACIAS = {"de", "del", "la", "las", "el", "los", "y", "en", "a", "para", "por", "con", "demo", "obra", "obras", "proyecto", "municipio", "sede"}


def palabras(nombre: str) -> set[str]:
    sin = unicodedata.normalize("NFKD", nombre.lower()).encode("ascii", "ignore").decode()
    return {w for w in re.findall(r"[a-z0-9]+", sin) if w not in _VACIAS and len(w) > 1}


def parecido(a: str, b: str) -> float:
    """Índice de Jaccard sobre las palabras con significado: compartidas / totales."""
    pa, pb = palabras(a), palabras(b)
    return round(len(pa & pb) / len(pa | pb), 3) if pa and pb else 0.0


def centro(poligono: list) -> tuple[float, float]:
    return (sum(p[0] for p in poligono) / len(poligono), sum(p[1] for p in poligono) / len(poligono))


def metros(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Distancia de círculo máximo (haversine) entre dos puntos (lon, lat)."""
    r = 6_371_000
    f1, f2 = math.radians(a[1]), math.radians(b[1])
    h = math.sin((f2 - f1) / 2) ** 2 + math.cos(f1) * math.cos(f2) * math.sin(math.radians(b[0] - a[0]) / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def comparar(proyecto: dict, intervencion: dict) -> dict | None:
    """proyecto: {nombre, municipio_dane, sector, poligono}; intervencion: {id, nombre, municipio_dane, sector, lon, lat}."""
    if proyecto["municipio_dane"] != intervencion.get("municipio_dane"):
        return None
    motivos, sector = [], bool(intervencion.get("sector")) and intervencion["sector"] == proyecto["sector"]
    par = parecido(proyecto["nombre"], intervencion.get("nombre", ""))
    cerca = None
    if proyecto.get("poligono") and intervencion.get("lon") is not None and intervencion.get("lat") is not None:
        cerca = metros(centro(proyecto["poligono"]), (intervencion["lon"], intervencion["lat"]))
    if cerca is not None and cerca <= RADIO_M:
        motivos.append(f"a {cerca:.0f} m del centro del polígono")
    if par >= PARECIDO:
        motivos.append(f"nombres parecidos ({par:.0%} de palabras compartidas)")
    if sector:
        motivos.append("mismo sector")
    sitio, nombre = cerca is not None and cerca <= RADIO_M, par >= PARECIDO
    if not ((sitio and sector) or (nombre and sector) or (sitio and nombre)):
        return None
    puntaje = round(0.45 * sitio + 0.35 * par + 0.20 * sector, 3)
    return {"id_ungrd": str(intervencion["id"]), "nombre_ungrd": intervencion.get("nombre", ""), "motivos": motivos,
            "nivel": "alto" if sitio and nombre and sector else "medio", "puntaje": puntaje}
