"""Identidad, roles y separación de funciones.

En desarrollo los tokens son JWT firmados con un secreto local. En producción la
identidad debe venir del proveedor institucional (OIDC con doble factor); esta
capa solo necesita `sub` y `rol` en el token.
"""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
import jwt
from sqlalchemy import select
from sqlalchemy.orm import Session
from . import config
from .db import Evento

ROLES = {"gerente", "consejo", "comite", "ventanilla", "interventoria", "fiducoldex", "unidad_datos",
         "control_interno", "cumplimiento", "ungrd", "observatorio", "auditor", "atencion"}
SOLO_LECTURA = {"observatorio", "auditor"}

PERMISOS = {
    "crear_proyecto": {"ventanilla", "unidad_datos"},
    "aprobar": {"gerente", "comite", "consejo"},
    "firmar": {"fiducoldex"},
    "registrar_adicion": {"ventanilla", "comite"},
    "cargar_evidencia": {"interventoria"},
    "certificar": {"interventoria"},
    "autorizar": {"gerente"},
    "pagar": {"fiducoldex"},
    "bloqueos": {"cumplimiento", "gerente", "ventanilla"},
    "corridas": {"unidad_datos"},
    "decidir_bandera": {"control_interno", "comite", "ungrd"},
    "responder_alerta": {"gerente", "control_interno"},
    "ia": {"unidad_datos", "control_interno", "comite", "atencion", "gerente"},
    "atender_casos": {"atencion"},
    "documentos": {"atencion", "unidad_datos"},
    "decidir_duplicado": {"control_interno", "comite", "ungrd"},
    "leer_interno": ROLES,
}
APRUEBA_BANDA = {"baja": {"gerente"}, "media": {"comite"}, "alta": {"consejo"}}

# quien hizo la primera acción sobre un ID-SISMO no puede hacer la segunda sobre el mismo
INCOMPATIBLES = {frozenset(p) for p in (("aprobar", "certificar"), ("certificar", "autorizar"), ("certificar", "pagar"),
                                         ("aprobar", "pagar"), ("autorizar", "pagar"), ("firmar", "certificar"))}


class Prohibido(Exception):
    def __init__(self, motivo: str):
        super().__init__(motivo)
        self.motivo = motivo


def emitir_token(sub: str, rol: str, horas: int = 8) -> str:
    if rol not in ROLES:
        raise ValueError(f"rol desconocido: {rol}")
    return jwt.encode({"sub": sub, "rol": rol, "exp": datetime.now(timezone.utc) + timedelta(hours=horas)}, config.SECRETO(), algorithm="HS256")


_oidc: dict = {}


def proveedor_oidc():
    """El verificador de identidad institucional, o None si no está configurado."""
    if not config.OIDC_EMISOR():
        return None
    clave = (config.OIDC_EMISOR(), config.OIDC_AUDIENCIA(), config.OIDC_CLAIM_ROL(), config.OIDC_ACR())
    if clave not in _oidc:
        from .identidad import Oidc
        _oidc.clear()
        _oidc[clave] = Oidc(clave[0], clave[1], ROLES, clave[2], True, clave[3])
    return _oidc[clave]


def leer_token(token: str) -> dict:
    p = proveedor_oidc()
    if p is not None:
        return p.leer(token)                  # con identidad institucional configurada, el token local deja de valer
    return jwt.decode(token, config.SECRETO(), algorithms=["HS256"])


def exigir_permiso(rol: str, accion: str):
    if rol not in PERMISOS.get(accion, set()):
        raise Prohibido(f"el rol «{rol}» no puede «{accion}»")


def conflicto_de_funciones(s: Session, id_sismo: str, actor: str, accion: str) -> str | None:
    """Devuelve la acción previa del mismo actor que choca con la nueva, si existe."""
    previas = s.execute(select(Evento.tipo).where(Evento.referencia == id_sismo, Evento.actor == actor)).scalars().all()
    for p in previas:
        if frozenset((p, accion)) in INCOMPATIBLES:
            return p
    return None
