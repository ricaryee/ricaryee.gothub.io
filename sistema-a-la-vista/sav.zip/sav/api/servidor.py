from .main import crear_app

app = crear_app()
