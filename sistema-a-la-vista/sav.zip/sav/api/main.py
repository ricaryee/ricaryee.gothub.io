"""API del Sistema a la Vista. Documentación interactiva en /docs (OpenAPI)."""
from datetime import date, datetime
from typing import Literal
from fastapi import Depends, FastAPI, Header, HTTPException, Request
import os
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from .. import bitacora, canales, cifrado, config, contratacion, idsismo, oc4ids, reglas, seguridad as seg, servicios as sv
from ..conectores.copernicus import Catalogo
from ..db import Acceso, Activacion, Alerta, Bandera, Bloqueo, CasoAtencion, Contrato, DocumentoOficial, Duplicado, Evento, Hito, Proyecto, RevisionSatelital, crear_esquema, crear_motor, fabrica
from .. import tablero as mod_tablero
from ..conectores.secop2 import Secop2
from ..conectores.simuladores import UngrdSimulado
from fastapi.responses import PlainTextResponse
from ..ia import agentes



def crear_app(motor=None) -> FastAPI:
    config.validar_produccion()
    motor = motor or crear_motor()
    crear_esquema(motor)
    Sesion = fabrica(motor)
    app = FastAPI(title="Sistema a la Vista", version="0.1.0",
                  description="Plataforma ID-SISMO: trazabilidad de cada peso, de la fuente al pago. Versión de desarrollo con fuentes simuladas salvo SECOP II.")

    def db():
        with Sesion() as s:
            yield s

    def usuario(request: Request, authorization: str | None = Header(default=None)) -> dict:
        if not authorization or not authorization.lower().startswith("bearer "):
            raise HTTPException(401, "Falta el token")
        try:
            u = seg.leer_token(authorization.split(" ", 1)[1])
        except Exception:
            raise HTTPException(401, "Token inválido o vencido")
        request.state.actor, request.state.rol = u["sub"], u["rol"]
        return u

    def escritor(u: dict = Depends(usuario)) -> dict:
        if u["rol"] in seg.SOLO_LECTURA:
            raise HTTPException(403, "Su acceso es de solo lectura")
        return u

    @app.middleware("http")
    async def auditoria(request: Request, call_next):
        """Cada llamada queda registrada: quién, con qué rol, qué pidió y qué obtuvo."""
        request.state.actor, request.state.rol = "publico", "publico"
        resp = await call_next(request)
        if request.url.path not in ("/salud", "/docs", "/openapi.json"):
            with Sesion() as s:
                s.add(Acceso(actor=request.state.actor, rol=request.state.rol, metodo=request.method, ruta=request.url.path[:300], estado=resp.status_code))
                s.commit()
        return resp

    @app.exception_handler(sv.Rechazo)
    async def _rechazo(_, e: sv.Rechazo):
        return JSONResponse({"detalle": e.motivo, "regla": e.activacion}, status_code=409)

    @app.exception_handler(seg.Prohibido)
    async def _prohibido(_, e: seg.Prohibido):
        return JSONResponse({"detalle": e.motivo}, status_code=403)

    @app.exception_handler(sv.NoExiste)
    async def _noexiste(_, e: sv.NoExiste):
        return JSONResponse({"detalle": str(e)}, status_code=404)

    @app.exception_handler(ValueError)
    async def _valor(_, e: ValueError):
        return JSONResponse({"detalle": str(e)}, status_code=422)

    # ------------------------------------------------------------ esquemas
    class Ficha(BaseModel):
        nombre: str = ""
        municipio_dane: str = ""
        municipio: str = ""
        zona: int = Field(0, ge=0, le=5)
        sector: str = ""
        valor: float | None = Field(None, gt=0)
        bpin: str = ""
        admisibilidad: str = ""
        poligono: list[tuple[float, float]] = []
        cronograma: list[dict] = []

    class HitoIn(BaseModel):
        valor: float = Field(gt=0)
        valor_planeado: float = Field(0, ge=0)

    class ContratoIn(BaseModel):
        id_secop: str | None = None
        publicado: bool = False
        contratista: str = Field(min_length=2)
        representante: str = ""
        constitucion_contratista: date | None = None
        oferentes: int = Field(0, ge=0)
        valor_inicial: float = Field(gt=0)
        inmuebles: bool = False
        items: list[dict] = []
        hitos: list[HitoIn] = []

    class AdicionIn(BaseModel):
        valor: float = Field(gt=0)
        aprobada_comite: bool = False

    class EvidenciaIn(BaseModel):
        contenido_b64: str
        lon: float = Field(ge=-180, le=180)
        lat: float = Field(ge=-90, le=90)
        capturada: datetime
        huella_dispositivo: str | None = Field(None, pattern="^[0-9a-fA-F]{64}$")

    class Periodo(BaseModel):
        desde: date
        hasta: date

    class CertificarIn(BaseModel):
        valor_ganado: float = Field(ge=0)

    class BloqueoIn(BaseModel):
        id_sismo: str
        descripcion: str = Field(min_length=5)
        dueno: str = Field(min_length=2)
        abierto: date

    class DecisionIn(BaseModel):
        confirmar: bool
        motivo: str = Field(min_length=5)

    class AlertaIn(BaseModel):
        tipo: Literal["riesgo", "anomalia", "irregular"]
        texto: str = Field(min_length=10, max_length=4000)
        municipio: str = ""

    class RespuestaIn(BaseModel):
        respuesta: str = Field(min_length=5)
        evidencia: str = ""

    class Fecha(BaseModel):
        fecha: date

    class PreguntaIn(BaseModel):
        pregunta: str = Field(min_length=3, max_length=1500)
        documentos: list[dict] = []
        autenticado: bool = False

    class OficialIn(BaseModel):
        titulo: str = Field(min_length=5, max_length=200)
        texto: str = Field(min_length=20, max_length=20000)

    class CierreCasoIn(BaseModel):
        respuesta: str = Field(min_length=10, max_length=3000)
        llamada_hecha: bool = False

    class VozIn(BaseModel):
        llamada: str = Field(min_length=3, max_length=120)
        turno: int = Field(ge=0, le=500)
        numero: str = Field(min_length=7, max_length=20, pattern=r"^\+?\d+$")
        texto: str = Field(max_length=2000)

    class DocumentoIn(BaseModel):
        texto: str = Field(min_length=20)
        requisitos: list[str] = Field(min_length=1)

    class TokenIn(BaseModel):
        sub: str = Field(min_length=2)
        rol: str

    # ------------------------------------------------------------ salud y acceso
    @app.get("/salud", tags=["sistema"])
    def salud():
        return {"estado": "ok", "entorno": config.ENTORNO()}

    @app.post("/auth/token-desarrollo", tags=["sistema"], summary="Solo en desarrollo: emite un token para un rol")
    def token_dev(t: TokenIn):
        if config.ENTORNO() != "dev" or config.OIDC_EMISOR():
            raise HTTPException(404, "No disponible")
        return {"token": seg.emitir_token(t.sub, t.rol)}

    # ------------------------------------------------------------ público, sin registro
    @app.get("/publico/resumen", tags=["público"])
    def resumen(s=Depends(db)):
        return sv.resumen_publico(s)

    @app.get("/publico/proyectos", tags=["público"])
    def proyectos(municipio_dane: str | None = None, s=Depends(db)):
        q = select(Proyecto).order_by(Proyecto.id_sismo)
        if municipio_dane:
            q = q.where(Proyecto.municipio_dane == municipio_dane)
        return [sv.proyecto_publico(p) for p in s.execute(q).scalars()]

    @app.get("/publico/proyectos/{id_sismo}", tags=["público"])
    def proyecto(id_sismo: str, s=Depends(db)):
        if not idsismo.es_valido(id_sismo):
            raise HTTPException(422, "ID-SISMO mal formado")
        return sv.proyecto_publico(sv._obtener(s, Proyecto, id_sismo))

    @app.get("/publico/proyectos/{id_sismo}/bitacora", tags=["público"], summary="El viaje de un peso: eventos encadenados del proyecto")
    def viaje(id_sismo: str, s=Depends(db)):
        sv._obtener(s, Proyecto, id_sismo)
        evs = s.execute(select(Evento).where(Evento.referencia == id_sismo).order_by(Evento.seq)).scalars()
        return [{"seq": e.seq, "ts": e.ts, "tipo": e.tipo, "rol": e.rol, "anterior": e.anterior, "huella": e.huella} for e in evs]

    @app.get("/publico/oc4ids/{id_sismo}", tags=["público"], summary="Paquete OC4IDS 0.9.5 del proyecto")
    def paquete(id_sismo: str, request: Request, s=Depends(db)):
        return oc4ids.paquete(s, sv._obtener(s, Proyecto, id_sismo), str(request.base_url).rstrip("/"))

    @app.get("/publico/bitacora/verificar", tags=["público"], summary="Recalcula toda la cadena de huellas")
    def verificar(s=Depends(db)):
        return bitacora.verificar(s)

    @app.get("/publico/alertas", tags=["público"])
    def alertas(s=Depends(db)):
        return [{"id": a.id, "tipo": a.tipo, "municipio": a.municipio, "recibida": a.recibida, "vence": a.vence, "estado": a.estado,
                 "respuesta": a.respuesta} for a in s.execute(select(Alerta).order_by(Alerta.id.desc())).scalars()]

    @app.post("/publico/alertas", tags=["público"], status_code=201)
    def radicar(a: AlertaIn, s=Depends(db)):
        x = sv.radicar_alerta(s, a.tipo, a.texto, a.municipio, date.today())
        return {"id": x.id, "vence": x.vence, "estado": x.estado}

    @app.get("/publico/reglas", tags=["público"], summary="Activaciones de las doce reglas")
    def activaciones(s=Depends(db)):
        return [{"regla": a.regla, "nombre": reglas.REGLAS[a.regla][0], "referencia": a.referencia, "accion": a.accion,
                 "responsable": a.responsable, "vence": a.vence, "abierta": a.abierta, "datos": a.datos}
                for a in s.execute(select(Activacion).order_by(Activacion.id.desc())).scalars()]

    @app.get("/publico/banda", tags=["público"], summary="Qué instancia aprueba un contrato según su valor")
    def banda(valor: float, inmuebles: bool = False):
        b = contratacion.banda(valor, inmuebles)
        return {"smmlv": round(contratacion.en_smmlv(valor), 2), "banda": b, "aprueba": contratacion.BANDAS[b]}

    @app.post("/publico/asistente", tags=["público"])
    def asistente(p: PreguntaIn, s=Depends(db)):
        docs = p.documentos or [{"titulo": d.titulo, "texto": d.texto} for d in s.execute(select(DocumentoOficial).where(DocumentoOficial.vigente.is_(True))).scalars()]
        return agentes.asistente(s, p.pregunta, docs, p.autenticado)

    # ------------------------------------------------------------ operación
    @app.post("/proyectos", tags=["operación"], status_code=201)
    def crear_proyecto(f: Ficha, u=Depends(escritor), s=Depends(db)):
        p = sv.crear_proyecto(s, f.model_dump(), u["sub"], u["rol"])
        return {"id_sismo": p.id_sismo}

    @app.post("/proyectos/{id_sismo}/contratos", tags=["operación"], status_code=201)
    def crear_contrato(id_sismo: str, c: ContratoIn, u=Depends(escritor), s=Depends(db)):
        x = sv.registrar_contrato(s, id_sismo, c.model_dump(), u["sub"], u["rol"])
        return {"id": x.id, "banda": x.banda, "hitos": [h.id for h in x.hitos]}

    @app.post("/contratos/{cid}/firmar", tags=["operación"])
    def firmar(cid: int, u=Depends(escritor), s=Depends(db)):
        x = sv.firmar_contrato(s, cid, u["sub"], u["rol"])
        return {"id": x.id, "firmado": x.firmado, "firma": x.firma}

    @app.post("/contratos/{cid}/adiciones", tags=["operación"])
    def adicion(cid: int, a: AdicionIn, u=Depends(escritor), s=Depends(db)):
        x = sv.registrar_adicion(s, cid, a.valor, a.aprobada_comite, u["sub"], u["rol"])
        return {"id": x.id, "adiciones": x.adiciones, "porcentaje": round(x.adiciones / x.valor_inicial, 4)}

    @app.post("/hitos/{hid}/evidencias", tags=["operación"], status_code=201)
    def evidencia(hid: int, e: EvidenciaIn, u=Depends(escritor), s=Depends(db)):
        x = sv.cargar_evidencia(s, hid, e.contenido_b64, e.lon, e.lat, e.capturada, u["sub"], u["rol"], e.huella_dispositivo)
        return {"id": x.id, "huella": x.huella, "en_geocerca": x.en_geocerca, "hora_coherente": x.hora_coherente, "repetida": x.repetida, "sello": x.sello}

    @app.post("/hitos/{hid}/certificar", tags=["operación"])
    def certificar(hid: int, c: CertificarIn, u=Depends(escritor), s=Depends(db)):
        return {"hito": hid, "estado": sv.certificar_hito(s, hid, c.valor_ganado, u["sub"], u["rol"]).estado}

    @app.get("/hitos/{hid}/pagable", tags=["operación"], summary="Lo que la fiduciaria consulta antes de instruir un giro")
    def pagable(hid: int, u=Depends(usuario), s=Depends(db)):
        return sv.estado_pago(s, hid)

    @app.post("/hitos/{hid}/autorizar", tags=["operación"])
    def autorizar(hid: int, u=Depends(escritor), s=Depends(db)):
        h = sv.autorizar_pago(s, hid, u["sub"], u["rol"])
        return {"hito": hid, "estado": h.estado, "plazo_pago": h.plazo_pago}

    @app.post("/hitos/{hid}/pagar", tags=["operación"])
    def pagar(hid: int, u=Depends(escritor), s=Depends(db)):
        h = sv.pagar(s, hid, u["sub"], u["rol"])
        return {"hito": hid, "estado": h.estado, "pagado": h.pagado}

    @app.post("/bloqueos", tags=["operación"], status_code=201)
    def bloqueo(b: BloqueoIn, u=Depends(escritor), s=Depends(db)):
        return {"id": sv.abrir_bloqueo(s, b.id_sismo, b.descripcion, b.dueno, b.abierto, u["sub"], u["rol"]).id}

    @app.get("/bloqueos", tags=["operación"])
    def bloqueos(u=Depends(usuario), s=Depends(db)):
        return [{"id": b.id, "id_sismo": b.id_sismo, "descripcion": b.descripcion, "dueno": b.dueno, "abierto": b.abierto, "nivel": b.nivel,
                 "vencido": b.vencido} for b in s.execute(select(Bloqueo).where(Bloqueo.cerrado.is_(None))).scalars()]

    @app.post("/bloqueos/{bid}/cerrar", tags=["operación"])
    def cerrar(bid: int, u=Depends(escritor), s=Depends(db)):
        return {"id": sv.cerrar_bloqueo(s, bid, date.today(), u["sub"], u["rol"]).id, "cerrado": True}

    @app.get("/banderas", tags=["operación"])
    def banderas(u=Depends(usuario), s=Depends(db)):
        return [{"id": b.id, "bandera": b.bandera, "nombre": b.nombre, "referencia": b.referencia, "dato": b.dato, "decide": b.decide,
                 "detectada": b.detectada, "estado": b.estado, "motivo": b.motivo} for b in s.execute(select(Bandera).order_by(Bandera.id.desc())).scalars()]

    @app.post("/banderas/{bid}/decidir", tags=["operación"])
    def decidir(bid: int, d: DecisionIn, u=Depends(escritor), s=Depends(db)):
        return {"id": bid, "estado": sv.decidir_bandera(s, bid, d.confirmar, d.motivo, u["sub"], u["rol"]).estado}

    @app.post("/alertas/{aid}/responder", tags=["operación"])
    def responder(aid: int, r: RespuestaIn, u=Depends(escritor), s=Depends(db)):
        return {"id": aid, "estado": sv.responder_alerta(s, aid, r.respuesta, r.evidencia, u["sub"], u["rol"]).estado}

    # ------------------------------------------------------------ corridas programadas
    def _corrida(u):
        seg.exigir_permiso(u["rol"], "corridas")

    @app.post("/corridas/diaria", tags=["corridas"], summary="Bloqueos (regla 7), alertas (regla 9), banderas y sello de tiempo")
    def diaria(f: Fecha, u=Depends(escritor), s=Depends(db)):
        _corrida(u)
        return sv.corrida_diaria(s, f.fecha)

    @app.post("/corridas/mensual", tags=["corridas"], summary="Valor ganado: reglas 5 y 6")
    def mensual(f: Fecha, u=Depends(escritor), s=Depends(db)):
        _corrida(u)
        return sv.corte_mensual(s, f.fecha)

    @app.post("/corridas/secop", tags=["corridas"], summary="Concilia con SECOP II: marca qué contratos están publicados")
    def conciliar_secop(u=Depends(escritor), s=Depends(db)):
        _corrida(u)
        return sv.conciliar_secop(s, getattr(app.state, "secop", None) or Secop2())

    @app.post("/corridas/satelite", tags=["corridas"], summary="Segundo testigo: obras de más de 10.000 SMMLV contra el catálogo de Copernicus")
    def corrida_satelite(p: Periodo, u=Depends(escritor), s=Depends(db)):
        _corrida(u)
        return sv.revision_satelital(s, p.desde, p.hasta, getattr(app.state, "catalogo", None) or Catalogo(), getattr(app.state, "pixeles", None))

    @app.get("/publico/proyectos/{id_sismo}/satelite", tags=["público"])
    def satelite_proyecto(id_sismo: str, s=Depends(db)):
        sv._obtener(s, Proyecto, id_sismo)
        return [{"desde": r.desde, "hasta": r.hasta, "estado": r.estado, **r.resultado}
                for r in s.execute(select(RevisionSatelital).where(RevisionSatelital.id_sismo == id_sismo).order_by(RevisionSatelital.id.desc())).scalars()]

    # ------------------------------------------------------------ app de obra
    # ------------------------------------------------------------ duplicados con la UNGRD
    @app.post("/corridas/duplicados", tags=["corridas"], summary="Cruza cada proyecto con las intervenciones de la UNGRD en su municipio")
    def cruce_duplicados(u=Depends(escritor), s=Depends(db)):
        _corrida(u)
        reg = getattr(app.state, "ungrd", None)
        if reg is None and config.ENTORNO() != "prod":
            from ..demo import UNGRD_DEMO
            reg = UngrdSimulado(UNGRD_DEMO)          # en desarrollo: registro ficticio, marcado [DEMO]
        if reg is None:
            raise HTTPException(503, "No hay registro de la UNGRD conectado. Exige convenio de intercambio de datos.")
        return sv.corrida_duplicados(s, reg)

    def _dup(d: Duplicado) -> dict:
        return {"id": d.id, "id_sismo": d.id_sismo, "id_ungrd": d.id_ungrd, "nombre_ungrd": d.nombre_ungrd, "nivel": d.nivel, "puntaje": d.puntaje,
                "motivos": d.motivos, "estado": d.estado, "motivo": d.motivo, "decidido_por": d.decidido_por, "detectado": d.detectado}

    @app.get("/duplicados", tags=["operación"])
    def duplicados(u=Depends(usuario), s=Depends(db)):
        return [_dup(d) for d in s.execute(select(Duplicado).order_by(Duplicado.estado.desc(), Duplicado.puntaje.desc())).scalars()]

    @app.post("/duplicados/{did}/decidir", tags=["operación"])
    def decidir_duplicado(did: int, d: DecisionIn, u=Depends(escritor), s=Depends(db)):
        return _dup(sv.decidir_duplicado(s, did, d.confirmar, d.motivo, u["sub"], u["rol"]))

    # ------------------------------------------------------------ atención: documentos, casos y canales
    def _doc(d: DocumentoOficial) -> dict:
        return {"id": d.id, "titulo": d.titulo, "texto": d.texto, "vigente": d.vigente, "actualizado": d.actualizado}

    @app.get("/publico/documentos", tags=["público"], summary="Los documentos oficiales que el asistente puede citar")
    def documentos(s=Depends(db)):
        return [_doc(d) for d in s.execute(select(DocumentoOficial).where(DocumentoOficial.vigente.is_(True)).order_by(DocumentoOficial.titulo)).scalars()]

    @app.post("/documentos", tags=["atención"], status_code=201)
    def publicar_documento(d: OficialIn, u=Depends(escritor), s=Depends(db)):
        return _doc(sv.publicar_documento(s, d.titulo, d.texto, u["sub"], u["rol"]))

    @app.post("/documentos/{did}/retirar", tags=["atención"])
    def retirar_documento(did: int, u=Depends(escritor), s=Depends(db)):
        return _doc(sv.retirar_documento(s, did, u["sub"], u["rol"]))

    @app.get("/atencion/casos", tags=["atención"], summary="Casos que el asistente pasó a una persona. Solo atención ve el número")
    def casos(u=Depends(usuario), s=Depends(db)):
        ve = u["rol"] in seg.PERMISOS["atender_casos"]
        return [{"id": k.id, "canal": k.canal, "abierto": k.abierto, "vence": k.vence, "estado": k.estado, "pregunta": k.pregunta if ve else None,
                 "numero": cifrado.descifrar(k.numero) if ve else None, "respuesta": k.respuesta if ve else None, "atendido_por": k.atendido_por, "entregada": k.entregada}
                for k in s.execute(select(CasoAtencion).order_by(CasoAtencion.estado, CasoAtencion.vence)).scalars()]

    @app.post("/atencion/casos/{cid}/cerrar", tags=["atención"])
    def cerrar_caso(cid: int, c: CierreCasoIn, u=Depends(escritor), s=Depends(db)):
        k = sv.cerrar_caso(s, cid, c.respuesta, u["sub"], u["rol"], _emisor(), c.llamada_hecha)
        return {"id": k.id, "estado": k.estado, "entregada": k.entregada}

    def _emisor():
        if getattr(app.state, "emisor", None) is None:
            app.state.emisor = canales.emisor_por_defecto()
        return app.state.emisor

    @app.get("/canales/whatsapp", include_in_schema=False)
    def whatsapp_verificar(request: Request):
        q = request.query_params
        if config.WA_VERIFICACION() and q.get("hub.mode") == "subscribe" and q.get("hub.verify_token") == config.WA_VERIFICACION():
            return PlainTextResponse(q.get("hub.challenge", ""))
        raise HTTPException(403, "Verificación rechazada")

    @app.post("/canales/whatsapp", tags=["canales"], summary="Entrada de mensajes de WhatsApp (API en la nube de Meta), firmada")
    async def whatsapp(request: Request, s=Depends(db)):
        cuerpo = await request.body()
        if len(cuerpo) > 200_000 or not canales.firma_valida(cuerpo, request.headers.get("x-hub-signature-256"), config.WA_SECRETO_APP()):
            raise HTTPException(403, "Firma inválida")
        try:
            aviso = __import__("json").loads(cuerpo)
        except ValueError:
            raise HTTPException(400, "El cuerpo no es JSON")
        request.state.actor, request.state.rol = "whatsapp", "canal"
        n = 0
        for m in canales.extraer_whatsapp(aviso if isinstance(aviso, dict) else {}):
            r = canales.atender(s, "whatsapp", m["de"], m["texto"], m["id"], "text" if m["tipo"] == "text" else m["tipo"], getattr(app.state, "motor_ia", None))
            if r:
                _emisor().enviar(m["de"], r["respuesta"]); n += 1
        return {"atendidos": n}

    @app.post("/canales/voz", tags=["canales"], summary="Entrada de la línea telefónica: el proveedor envía lo que la persona dijo, ya transcrito")
    def voz(v: VozIn, request: Request, s=Depends(db), x_sav_firma: str | None = Header(default=None)):
        import hmac as _h, hashlib as _hl
        esperado = _h.new(config.VOZ_SECRETO().encode(), f"{v.llamada}:{v.turno}:{v.numero}".encode(), _hl.sha256).hexdigest() if config.VOZ_SECRETO() else None
        if not esperado or not x_sav_firma or not _h.compare_digest(esperado, x_sav_firma):
            raise HTTPException(403, "Firma inválida")
        request.state.actor, request.state.rol = "voz", "canal"
        r = canales.atender(s, "voz", v.numero, v.texto, f"{v.llamada}:{v.turno}", "text", getattr(app.state, "motor_ia", None))
        if not r:
            return {"decir": "", "transferir": False, "caso": None}
        return {"decir": r["respuesta"], "transferir": r["paso_a_persona"], "caso": r["caso"]}

    @app.get("/obra/hitos", tags=["app de obra"], summary="Hitos que esperan evidencia, con la geocerca, para trabajar sin señal")
    def obra_hitos(u=Depends(usuario), s=Depends(db)):
        seg.exigir_permiso(u["rol"], "cargar_evidencia")
        out = []
        for h in s.execute(select(Hito).where(Hito.estado.in_(("pendiente", "devuelto"))).order_by(Hito.id)).scalars():
            c = h.contrato
            if c.firmado:
                out.append({"hito": h.id, "numero": h.numero, "estado": h.estado, "id_sismo": c.id_sismo, "proyecto": c.proyecto.nombre,
                            "municipio": c.proyecto.municipio, "poligono": c.proyecto.ficha.get("poligono"), "evidencias": len(h.evidencias)})
        return out

    # ------------------------------------------------------------ consola interna
    @app.get("/tablero", tags=["consola"], summary="Indicadores calculados desde la base")
    def tablero(u=Depends(usuario), s=Depends(db)):
        return mod_tablero.calcular(s)

    @app.get("/contratos", tags=["consola"], summary="Contratos con sus hitos y el estado de pago de cada uno")
    def contratos(u=Depends(usuario), s=Depends(db)):
        out = []
        for c in s.execute(select(Contrato).order_by(Contrato.id)).scalars():
            out.append({"id": c.id, "id_sismo": c.id_sismo, "proyecto": c.proyecto.nombre, "contratista": c.contratista, "id_secop": c.id_secop,
                        "publicado": c.publicado, "firmado": c.firmado, "banda": c.banda, "valor_inicial": c.valor_inicial, "adiciones": c.adiciones,
                        "avance": sv.avance(c),
                        "hitos": [{"id": h.id, "numero": h.numero, "valor": h.valor, "estado": h.estado, "evidencias": len(h.evidencias),
                                   "plazo_pago": h.plazo_pago, "pago": sv.estado_pago(s, h.id)} for h in c.hitos]})
        return out

    @app.get("/yo", tags=["consola"])
    def yo(u=Depends(usuario)):
        return {"sub": u["sub"], "rol": u["rol"], "solo_lectura": u["rol"] in seg.SOLO_LECTURA,
                "puede": sorted(a for a, r in seg.PERMISOS.items() if u["rol"] in r), "roles": sorted(seg.ROLES)}

    # ------------------------------------------------------------ auditoría e IA
    @app.get("/auditoria/accesos", tags=["auditoría"])
    def accesos(limite: int = 200, u=Depends(usuario), s=Depends(db)):
        if u["rol"] not in ("auditor", "control_interno"):
            raise HTTPException(403, "Solo auditoría y control interno")
        return [{"ts": a.ts, "actor": a.actor, "rol": a.rol, "metodo": a.metodo, "ruta": a.ruta, "estado": a.estado}
                for a in s.execute(select(Acceso).order_by(Acceso.id.desc()).limit(min(limite, 1000))).scalars()]

    @app.get("/auditoria/continua", tags=["auditoría"], summary="Agente auditor: hallazgos deterministas y resumen redactado")
    def auditoria_continua(u=Depends(usuario), s=Depends(db)):
        if u["rol"] not in ("auditor", "control_interno", "gerente"):
            raise HTTPException(403, "Solo auditoría, control interno y gerencia")
        return agentes.auditor(s, u["sub"])

    @app.post("/ia/banderas/{bid}/explicar", tags=["IA"])
    def explicar(bid: int, u=Depends(usuario), s=Depends(db)):
        seg.exigir_permiso(u["rol"], "ia")
        return agentes.explicar_bandera(s, sv._obtener(s, Bandera, bid), u["sub"])

    @app.post("/ia/documentos/revisar", tags=["IA"])
    def revisar(d: DocumentoIn, u=Depends(usuario), s=Depends(db)):
        seg.exigir_permiso(u["rol"], "ia")
        return agentes.revisar_documento(s, d.texto, d.requisitos, u["sub"])

    _raiz = os.path.join(os.path.dirname(__file__), "..", "..")
    _portal = os.path.join(_raiz, "portal", "index.html")
    _CSP = {"Content-Security-Policy": "default-src 'self'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'",
            "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "Cache-Control": "no-store"}

    @app.get("/consola", include_in_schema=False)
    def consola():
        return FileResponse(os.path.join(_raiz, "consola", "index.html"), headers=_CSP)

    _obra = os.path.join(_raiz, "obra")

    @app.get("/obra", include_in_schema=False)
    def obra():
        return FileResponse(os.path.join(_obra, "index.html"), headers={**_CSP, "Content-Security-Policy": _CSP["Content-Security-Policy"].replace("img-src 'self' data:", "img-src 'self' data: blob:") + "; worker-src 'self'; manifest-src 'self'", "Cache-Control": "no-cache"})

    @app.get("/obra/sw.js", include_in_schema=False)
    def obra_sw():
        return FileResponse(os.path.join(_obra, "sw.js"), media_type="application/javascript", headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/obra"})

    @app.get("/obra/manifest.webmanifest", include_in_schema=False)
    def obra_manifest():
        return FileResponse(os.path.join(_obra, "manifest.webmanifest"), media_type="application/manifest+json")

    @app.get("/", include_in_schema=False)
    def portal():
        return FileResponse(_portal, headers=_CSP)

    return app
