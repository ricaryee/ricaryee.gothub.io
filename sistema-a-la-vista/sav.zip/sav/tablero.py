"""Tablero del gerente calculado desde la base. Solo muestra lo que los datos permiten medir."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from . import bitacora, calendario as cal
from .db import Activacion, Alerta, Bandera, Bloqueo, Contrato, Hito, Proyecto
from .servicios import avance


def _ind(clave, nombre, valor, unidad="", meta=None, mejor="mayor"):
    estado = None
    if valor is not None and meta is not None:
        cumple = valor >= meta if mejor == "mayor" else valor <= meta
        cerca = valor >= meta * 0.9 if mejor == "mayor" else valor <= (meta * 1.1 if meta else 0)
        estado = "verde" if cumple else "amarillo" if cerca else "rojo"
    return {"clave": clave, "nombre": nombre, "valor": valor, "unidad": unidad, "meta": meta, "estado": estado}


def calcular(s: Session) -> dict:
    total = s.execute(select(func.coalesce(func.sum(Proyecto.valor), 0))).scalar()
    firmados = s.execute(select(Contrato).where(Contrato.firmado.is_(True))).scalars().all()
    contratado = sum(c.valor_inicial + c.adiciones for c in firmados)
    vp = vg = 0.0
    for c in firmados:
        a = avance(c)
        if a["vp"]:
            vp, vg = vp + a["vp"], vg + a["vg"]
    pagados = s.execute(select(Hito).where(Hito.estado == "pagado")).scalars().all()
    dias = [cal.habiles_entre(h.orden_pago, h.pagado) for h in pagados if h.orden_pago and h.pagado]
    con_ev = sum(1 for h in pagados if h.acta_firmada and h.evidencias)
    cerradas = s.execute(select(func.count()).select_from(Alerta).where(Alerta.estado == "cerrada")).scalar()
    sin_resp = s.execute(select(func.count()).select_from(Alerta).where(Alerta.estado == "sin_respuesta")).scalar()
    limite = datetime.now(timezone.utc) - timedelta(hours=48)
    en_rev = s.execute(select(Bandera).where(Bandera.estado == "revision")).scalars().all()
    fuera = sum(1 for b in en_rev if (b.detectada if b.detectada.tzinfo else b.detectada.replace(tzinfo=timezone.utc)) < limite)
    ind = [
        _ind("ejecucion", "Ejecución: contratado sobre el valor de los proyectos", round(contratado / total * 100, 1) if total else None, "%"),
        _ind("pagos_evidencia", "Pagos con acta y foto sellada", round(con_ev / len(pagados) * 100, 1) if pagados else None, "%", 100),
        _ind("pago_dias", "Días hábiles de la orden al pago", round(sum(dias) / len(dias), 1) if dias else None, "días", 5, "menor"),
        _ind("spi", "Avance físico (SPI)", round(vg / vp, 2) if vp else None, "", 0.95),
        _ind("bloqueos_vencidos", "Bloqueos de más de 20 días hábiles", s.execute(select(func.count()).select_from(Bloqueo).where(Bloqueo.cerrado.is_(None), Bloqueo.vencido.is_(True))).scalar(), "", 0, "menor"),
        _ind("alertas_a_tiempo", "Alertas cerradas a tiempo", round(cerradas / (cerradas + sin_resp) * 100, 1) if cerradas + sin_resp else None, "%", 90),
        _ind("banderas_fuera", "Banderas con más de 48 horas sin decisión", fuera, "", 0, "menor"),
        _ind("reglas_abiertas", "Activaciones de reglas abiertas", s.execute(select(func.count()).select_from(Activacion).where(Activacion.abierta.is_(True))).scalar()),
    ]
    return {"indicadores": ind, "bitacora": bitacora.verificar(s),
            "sin_fuente": ["Hogares con solución (UNGRD y MinVivienda)", "Costo administrativo (contabilidad del fondo)",
                           "Conversación en contra (medición externa)", "Publicación oportuna en SECOP II (requiere fecha de adjudicación)"]}
