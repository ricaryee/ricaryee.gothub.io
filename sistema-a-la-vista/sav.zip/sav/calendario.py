"""Calendario oficial de Colombia: festivos (Ley 51 de 1983) y días hábiles."""
from __future__ import annotations
from datetime import date, timedelta
from functools import lru_cache


def pascua(anio: int) -> date:
    a, b, c = anio % 19, anio // 100, anio % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = (h + l - 7 * m + 114) % 31 + 1
    return date(anio, mes, dia)


def _al_lunes(d: date) -> date:
    return d if d.weekday() == 0 else d + timedelta(days=7 - d.weekday())


@lru_cache(maxsize=None)
def festivos(anio: int) -> frozenset[date]:
    fijos = [(1, 1), (5, 1), (7, 20), (8, 7), (12, 8), (12, 25)]
    trasladables = [(1, 6), (3, 19), (6, 29), (8, 15), (10, 12), (11, 1), (11, 11)]
    p = pascua(anio)
    f = {date(anio, m, d) for m, d in fijos}
    f |= {_al_lunes(date(anio, m, d)) for m, d in trasladables}
    f |= {p - timedelta(days=3), p - timedelta(days=2)}            # Jueves y Viernes Santo
    f |= {_al_lunes(p + timedelta(days=d)) for d in (39, 60, 68)}  # Ascensión, Corpus, Sagrado Corazón
    return frozenset(f)


def es_habil(d: date) -> bool:
    return d.weekday() < 5 and d not in festivos(d.year)


def sumar_habiles(desde: date, n: int) -> date:
    """Fecha que resulta de contar n días hábiles después de `desde` (sin incluirlo)."""
    if n < 0:
        raise ValueError("n debe ser cero o positivo")
    d = desde
    while n:
        d += timedelta(days=1)
        if es_habil(d):
            n -= 1
    return d


def habiles_entre(desde: date, hasta: date) -> int:
    """Días hábiles transcurridos después de `desde` y hasta `hasta` inclusive."""
    n, d = 0, desde
    while d < hasta:
        d += timedelta(days=1)
        if es_habil(d):
            n += 1
    return n
