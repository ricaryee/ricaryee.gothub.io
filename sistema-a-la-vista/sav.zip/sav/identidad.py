"""Identidad institucional por OpenID Connect.

Con SAV_OIDC_EMISOR configurado, la plataforma deja de aceptar los tokens locales de desarrollo y solo
admite los que firma el proveedor de identidad de la entidad. Cada token debe traer:
  - firma válida con una llave publicada por el emisor (RS256, PS256 o ES256; nunca HS256 ni «none»),
  - emisor y audiencia exactos, y vigencia,
  - prueba de doble factor (amr con «mfa», o un acr de la lista SAV_OIDC_ACR),
  - exactamente un rol del sistema: dos roles en una misma persona rompen la separación de funciones.
"""
from __future__ import annotations
import time
import httpx, jwt

ALGORITMOS = ("RS256", "PS256", "ES256")


class IdentidadInvalida(Exception):
    pass


class Oidc:
    def __init__(self, emisor: str, audiencia: str, roles: set[str], claim_rol: str = "rol", exigir_mfa: bool = True,
                 acr_validos: tuple[str, ...] = (), jwks_url: str | None = None, cliente: httpx.Client | None = None, vigencia_llaves: int = 600):
        self.emisor, self.audiencia, self.roles, self.claim_rol = emisor.rstrip("/"), audiencia, set(roles), claim_rol
        self.exigir_mfa, self.acr_validos = exigir_mfa, tuple(acr_validos)
        self._jwks_url, self._c, self._vig = jwks_url, cliente or httpx.Client(timeout=10), vigencia_llaves
        self._llaves: dict[str, object] = {}
        self._leidas = 0.0

    def _cargar(self):
        if not self._jwks_url:
            d = self._c.get(self.emisor + "/.well-known/openid-configuration"); d.raise_for_status()
            if d.json().get("issuer", "").rstrip("/") != self.emisor:
                raise IdentidadInvalida("el emisor publicado no coincide con el configurado")
            self._jwks_url = d.json()["jwks_uri"]
        r = self._c.get(self._jwks_url); r.raise_for_status()
        llaves = {}
        for k in r.json().get("keys", []):
            if k.get("kid") and k.get("use", "sig") == "sig" and k.get("kty") in ("RSA", "EC"):
                try:
                    llaves[k["kid"]] = jwt.PyJWK(k).key
                except Exception:
                    continue
        self._llaves, self._leidas = llaves, time.monotonic()

    def _llave(self, kid: str):
        if not self._llaves or time.monotonic() - self._leidas > self._vig:
            self._cargar()
        if kid not in self._llaves and time.monotonic() - self._leidas > 5:      # rotación de llaves: se relee una vez, sin dejarse inundar
            self._cargar()
        if kid not in self._llaves:
            raise IdentidadInvalida("el token viene firmado con una llave que el emisor no publica")
        return self._llaves[kid]

    def leer(self, token: str) -> dict:
        try:
            cab = jwt.get_unverified_header(token)
        except jwt.PyJWTError:
            raise IdentidadInvalida("token ilegible")
        if cab.get("alg") not in ALGORITMOS or not cab.get("kid"):
            raise IdentidadInvalida("algoritmo de firma no admitido")
        try:
            d = jwt.decode(token, self._llave(cab["kid"]), algorithms=[cab["alg"]], audience=self.audiencia, issuer=self.emisor,
                           leeway=30, options={"require": ["exp", "iat", "sub", "iss", "aud"]})
        except jwt.PyJWTError as e:
            raise IdentidadInvalida(f"token rechazado: {type(e).__name__}")
        except httpx.HTTPError:
            raise IdentidadInvalida("no fue posible consultar las llaves del emisor")
        if self.exigir_mfa:
            amr = d.get("amr") or []
            if not (("mfa" in amr) if isinstance(amr, list) else amr == "mfa") and d.get("acr") not in self.acr_validos:
                raise IdentidadInvalida("el ingreso no se hizo con doble factor")
        v = d.get(self.claim_rol)
        del_sistema = [r for r in ([v] if isinstance(v, str) else v if isinstance(v, list) else []) if r in self.roles]
        if len(del_sistema) != 1:
            raise IdentidadInvalida("la persona debe tener exactamente un rol del sistema")
        return {"sub": str(d.get("preferred_username") or d.get("email") or d["sub"])[:80], "rol": del_sistema[0]}
