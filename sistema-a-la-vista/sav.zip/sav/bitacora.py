"""Bitácora encadenada: cada evento lleva la huella SHA-256 del anterior.

Alterar un evento antiguo rompe todas las huellas siguientes y deja de coincidir
con el sello de tiempo de la noche. `verificar` recalcula toda la cadena.
"""
from __future__ import annotations
import hashlib
from sqlalchemy import select, text
from sqlalchemy.orm import Session
from .db import Evento, Sello, ahora
from .evidencia import canonico, AutoridadDeSellado

GENESIS = "0" * 64


def _huella(anterior: str, seq: int, ts: str, referencia: str, tipo: str, actor: str, rol: str, datos: str) -> str:
    return hashlib.sha256("|".join([anterior, str(seq), ts, referencia, tipo, actor, rol, datos]).encode()).hexdigest()


def registrar(s: Session, referencia: str, tipo: str, actor: str, rol: str, datos: dict | None = None) -> Evento:
    if s.bind.dialect.name == "postgresql":
        s.execute(text("SELECT pg_advisory_xact_lock(726001)"))  # una sola escritura a la vez
    ultimo = s.execute(select(Evento).order_by(Evento.seq.desc()).limit(1)).scalar_one_or_none()
    seq = (ultimo.seq + 1) if ultimo else 1
    anterior = ultimo.huella if ultimo else GENESIS
    ts, d = ahora().isoformat(), canonico(datos or {})
    ev = Evento(seq=seq, ts=ts, referencia=referencia, tipo=tipo, actor=actor, rol=rol, datos=d,
                anterior=anterior, huella=_huella(anterior, seq, ts, referencia, tipo, actor, rol, d))
    s.add(ev)
    s.flush()
    return ev


def verificar(s: Session) -> dict:
    """Recalcula la cadena completa. Devuelve el primer evento donde se rompe, si lo hay."""
    anterior, n = GENESIS, 0
    for ev in s.execute(select(Evento).order_by(Evento.seq)).scalars():
        n += 1
        if ev.seq != n or ev.anterior != anterior or ev.huella != _huella(ev.anterior, ev.seq, ev.ts, ev.referencia, ev.tipo, ev.actor, ev.rol, ev.datos):
            return {"integra": False, "eventos": n, "ruptura_en": ev.seq, "ultima_huella": None}
        anterior = ev.huella
    return {"integra": True, "eventos": n, "ruptura_en": None, "ultima_huella": anterior if n else None}


def sellar(s: Session, tsa: AutoridadDeSellado) -> Sello | None:
    """Sello de tiempo sobre la última huella. Se programa cada noche."""
    v = verificar(s)
    if not v["integra"] or not v["eventos"]:
        return None
    sello = Sello(seq=v["eventos"], huella=v["ultima_huella"], sello=tsa.sellar(v["ultima_huella"]))
    s.add(sello)
    s.flush()
    return sello


def verificar_sellos(s: Session, tsa: AutoridadDeSellado) -> dict:
    """Cada sello debe coincidir con la huella que la cadena tiene hoy en ese punto."""
    malos = []
    for se in s.execute(select(Sello).order_by(Sello.id)).scalars():
        ev = s.get(Evento, se.seq)
        if not ev or ev.huella != se.huella or not tsa.verificar(se.huella, se.sello):
            malos.append(se.id)
    return {"sellos": s.query(Sello).count(), "no_coinciden": malos}
