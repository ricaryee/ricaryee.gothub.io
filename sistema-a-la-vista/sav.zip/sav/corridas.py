"""Corridas programadas, para cron o un CronJob de Kubernetes.

    python -m sav.corridas diaria                 # cada noche
    python -m sav.corridas mensual                # el primer día hábil del mes
    python -m sav.corridas secop                  # conciliación con SECOP II
    python -m sav.corridas satelite               # del día 1 del mes a la fecha
    python -m sav.corridas diaria --fecha 2027-03-01

Reintenta ante fallas pasajeras y termina con código distinto de cero si no lo logra, para que el programador avise.
"""
from __future__ import annotations
import argparse, json, sys, time
from datetime import date
from . import servicios as sv
from .db import crear_esquema, crear_motor, fabrica


def ejecutar(cual: str, fecha: date, motor=None, secop=None, catalogo=None, intentos: int = 3, espera: float = 5.0, dormir=time.sleep) -> dict:
    motor = motor or crear_motor()
    crear_esquema(motor)
    ultimo = None
    for n in range(1, intentos + 1):
        try:
            with fabrica(motor)() as s:
                if cual == "diaria":
                    return sv.corrida_diaria(s, fecha)
                if cual == "mensual":
                    return {"activaciones": sv.corte_mensual(s, fecha)}
                if cual == "secop":
                    from .conectores.secop2 import Secop2
                    return sv.conciliar_secop(s, secop or Secop2())
                if cual == "satelite":
                    from .conectores.copernicus import Catalogo
                    return {"revisiones": sv.revision_satelital(s, fecha.replace(day=1), fecha, catalogo or Catalogo())}
                raise ValueError(f"corrida desconocida: {cual}")
        except ValueError:
            raise
        except Exception as e:                       # base caída, red caída: se reintenta
            ultimo = e
            if n < intentos:
                dormir(espera * n)
    raise RuntimeError(f"la corrida «{cual}» falló {intentos} veces: {type(ultimo).__name__}: {ultimo}")


def main(argv=None) -> int:
    a = argparse.ArgumentParser(description="Corridas programadas del Sistema a la Vista")
    a.add_argument("cual", choices=["diaria", "mensual", "secop", "satelite"])
    a.add_argument("--fecha", type=date.fromisoformat, default=date.today())
    p = a.parse_args(argv)
    try:
        print(json.dumps({"corrida": p.cual, "fecha": p.fecha.isoformat(), "resultado": ejecutar(p.cual, p.fecha)}, ensure_ascii=False, default=str))
        return 0
    except Exception as e:
        print(json.dumps({"corrida": p.cual, "error": str(e)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
