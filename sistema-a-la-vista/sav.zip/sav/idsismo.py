"""ID-SISMO: la llave única que une proyecto, proceso, contrato, hito, foto y pago."""
from __future__ import annotations
import re

SECTORES = {"VIV": "Vivienda", "INS": "Infraestructura social", "AEV": "Agua, energía y vías",
            "REC": "Reactivación económica", "APO": "Apoyos a hogares", "ALM": "Reconstrucción del alma"}
_RE = re.compile(r"^SISMO26-(\d{5})-(VIV|INS|AEV|REC|APO|ALM)-(\d{6})$")


class IdSismoInvalido(ValueError):
    pass


def construir(dane: str, sector: str, consecutivo: int) -> str:
    if not re.fullmatch(r"\d{5}", dane or ""):
        raise IdSismoInvalido("el código DANE del municipio tiene cinco dígitos")
    if sector not in SECTORES:
        raise IdSismoInvalido(f"sector desconocido: {sector}")
    if not 1 <= consecutivo <= 999_999:
        raise IdSismoInvalido("el consecutivo va de 1 a 999999")
    return f"SISMO26-{dane}-{sector}-{consecutivo:06d}"


def descomponer(id_sismo: str) -> dict:
    m = _RE.match(id_sismo or "")
    if not m:
        raise IdSismoInvalido(f"ID-SISMO mal formado: {id_sismo!r}")
    return {"dane": m[1], "sector": m[2], "consecutivo": int(m[3])}


def es_valido(id_sismo: str) -> bool:
    return bool(_RE.match(id_sismo or ""))
