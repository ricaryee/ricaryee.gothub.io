"""Configuración por variables de entorno. Ningún secreto vive en el código."""
import os


def env(nombre: str, defecto: str = "") -> str:
    return os.environ.get(nombre, defecto)


ENTORNO = lambda: env("SAV_ENTORNO", "dev")               # dev | prod
DB_URL = lambda: env("SAV_DB", "sqlite:///sav.db")
SECRETO = lambda: env("SAV_SECRETO", "solo-para-desarrollo-cambiar-antes-de-produccion")
LLAVE_SELLO = lambda: env("SAV_LLAVE_SELLO", "solo-para-desarrollo-llave-de-sello-local").encode()
MODELO_IA = lambda: env("SAV_MODELO_IA", "claude-sonnet-5-5")
SECOP_NIT = lambda: env("SAV_SECOP_NIT", "")              # NIT de la entidad contratante en SECOP II
DIR_EVIDENCIAS = lambda: env("SAV_DIR_EVIDENCIAS", "evidencias")

WA_VERIFICACION = lambda: env("SAV_WA_VERIFICACION", "")   # palabra que Meta devuelve al registrar el webhook
WA_SECRETO_APP = lambda: env("SAV_WA_SECRETO_APP", "")     # secreto de la aplicación de Meta: firma cada aviso
WA_TOKEN = lambda: env("SAV_WA_TOKEN", "")                 # vacío = las respuestas quedan en la bandeja de desarrollo
WA_TELEFONO_ID = lambda: env("SAV_WA_TELEFONO_ID", "")
WA_VERSION = lambda: env("SAV_WA_VERSION", "v21.0")
VOZ_SECRETO = lambda: env("SAV_VOZ_SECRETO", "")           # secreto compartido con el proveedor de la línea telefónica

OIDC_EMISOR = lambda: env("SAV_OIDC_EMISOR", "")           # con valor, solo se aceptan tokens de ese proveedor de identidad
OIDC_AUDIENCIA = lambda: env("SAV_OIDC_AUDIENCIA", "")
OIDC_CLAIM_ROL = lambda: env("SAV_OIDC_CLAIM_ROL", "rol")
OIDC_ACR = lambda: tuple(x.strip() for x in env("SAV_OIDC_ACR", "").split(",") if x.strip())
TSA_URL = lambda: env("SAV_TSA_URL", "")                   # autoridad de sellado RFC 3161; vacío = sello local sin valor probatorio
TSA_CA = lambda: env("SAV_TSA_CA", "")                     # archivo PEM con los certificados raíz de la autoridad
LLAVE_DATOS = lambda: env("SAV_LLAVE_DATOS", "solo-para-desarrollo-llave-de-datos-personales")


def validar_produccion():
    """En producción no se arranca con sustitutos: ni secretos de desarrollo, ni ingreso local, ni sello sin valor probatorio."""
    if ENTORNO() == "prod":
        malos = [n for n, v in (("SAV_SECRETO", SECRETO()), ("SAV_LLAVE_SELLO", LLAVE_SELLO().decode()), ("SAV_LLAVE_DATOS", LLAVE_DATOS())) if "desarrollo" in v or len(v) < 32]
        if malos:
            raise RuntimeError("En producción faltan secretos fuertes: " + ", ".join(malos))
        faltan = [n for n, v in (("SAV_OIDC_EMISOR", OIDC_EMISOR()), ("SAV_OIDC_AUDIENCIA", OIDC_AUDIENCIA()), ("SAV_TSA_URL", TSA_URL()), ("SAV_TSA_CA", TSA_CA())) if not v]
        if faltan:
            raise RuntimeError("En producción faltan: " + ", ".join(faltan) + ". Ver docs/PENDIENTES.md")
        if not OIDC_EMISOR().startswith("https://") or not TSA_URL().startswith("https://"):
            raise RuntimeError("En producción el emisor de identidad y la autoridad de sellado deben usar https")
