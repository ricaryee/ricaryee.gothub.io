"""Agentes de inteligencia artificial, con una persona al final de cada uno.

Reglas de gobierno (sección 9.4 de la propuesta), aplicadas en el código:
  1. Ningún agente aprueba, paga, excluye ni cambia el estado de nada: solo devuelve texto.
  2. Cada consulta queda en `consultas_ia` (registro de solo escritura) con el modelo usado.
  3. Las salvaguardas críticas son deterministas y corren ANTES y DESPUÉS del modelo.
  4. Sin llave de API el sistema sigue funcionando en «modo sin IA», con textos de plantilla.
Los datos personales no se envían al modelo: los agentes reciben seudónimos y datos de contratación pública.
"""
from __future__ import annotations
import hashlib, os, re
from typing import Protocol
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from .. import bitacora, config
from ..db import Bandera, ConsultaIA, Evento, Hito
from ..evidencia import SelladoSimulado, canonico


class Motor(Protocol):
    nombre: str
    def generar(self, sistema: str, mensaje: str) -> str: ...


class MotorSinIA:
    nombre = "sin-ia"

    def generar(self, sistema: str, mensaje: str) -> str:
        return ""


class MotorClaude:
    def __init__(self, modelo: str | None = None, cliente=None):
        import anthropic
        self._c = cliente or anthropic.Anthropic()  # lee ANTHROPIC_API_KEY del entorno
        self.nombre = modelo or config.MODELO_IA()

    def generar(self, sistema: str, mensaje: str) -> str:
        r = self._c.messages.create(model=self.nombre, max_tokens=900, system=sistema, messages=[{"role": "user", "content": mensaje}])
        return "".join(b.text for b in r.content if getattr(b, "type", "") == "text").strip()


def motor_por_defecto() -> Motor:
    return MotorClaude() if os.environ.get("ANTHROPIC_API_KEY") else MotorSinIA()


def _registrar(s: Session, uso: str, actor: str, motor: Motor, entrada: str, salida: str, persona: bool = False):
    s.add(ConsultaIA(uso=uso, actor=actor, modelo=motor.nombre, entrada_huella=hashlib.sha256(entrada.encode()).hexdigest(), salida=salida, paso_a_persona=persona))
    s.commit()


def _generar(motor: Motor, sistema: str, mensaje: str) -> str:
    try:
        return motor.generar(sistema, mensaje)
    except Exception:
        return ""  # si el proveedor falla, el servicio responde con la plantilla


# ---------------------------------------------------------------- 1. explicación de banderas
def explicar_bandera(s: Session, b: Bandera, actor: str, motor: Motor | None = None) -> dict:
    motor = motor or motor_por_defecto()
    hechos = f"Bandera {b.bandera}: {b.nombre}. Referencia: {b.referencia}. Dato que la disparó: {b.dato}. Decide: {b.decide}."
    sistema = ("Eres analista de control interno de un fondo público de reconstrucción en Colombia. Explica en español claro, en máximo "
               "120 palabras, por qué el dato amerita revisión y qué tres verificaciones concretas haría una persona. No afirmes que hubo "
               "una irregularidad: una bandera es una señal, no una conclusión. Usa solo los hechos dados.")
    texto = _generar(motor, sistema, hechos)
    if not texto:
        texto = (f"{b.nombre}: {b.dato}. Es una señal para revisar, no una conclusión. Verifique el expediente del proceso en SECOP II, "
                 "los soportes del dato y la explicación del área responsable antes de confirmar o descartar.")
    _registrar(s, "explicar_bandera", actor, motor, hechos, texto)
    return {"bandera": b.id, "explicacion": texto, "modelo": motor.nombre, "decide": b.decide, "nota": "La decisión es de una persona; este texto no cambia el estado de la bandera."}


# ---------------------------------------------------------------- 2. asistente ciudadano
_QUEJA = re.compile(r"\b(queja|quejo|reclam|denunci|demand|tutela|derecho de petici|abogad|corrup|me negaron|injust|no me han pagado|soborn|amenaz)", re.I)
_CASO = re.compile(r"\b(mi (caso|tr[aá]mite|subsidio|apoyo|arriendo|pago|solicitud)|cu[aá]ndo me)", re.I)
MSG_PERSONA = ("Esto debe atenderlo una persona. Dejé su mensaje radicado y un funcionario le responderá en un máximo de 10 días hábiles, "
               "como ordena la Ley 1755 de 2015.")
MSG_AUTENTICAR = "Para consultar su trámite necesito confirmar su identidad. Le enviaré un código al número registrado en el RUD."
MSG_SIN_FUENTE = "No encontré esa información en los documentos oficiales. Paso su pregunta a una persona para que le responda."


def asistente(s: Session, pregunta: str, documentos: list[dict], autenticado: bool = False, motor: Motor | None = None) -> dict:
    """documentos: [{titulo, texto}] oficiales. Responde solo con ellos y cita la fuente; ante duda o queja, pasa a una persona."""
    motor = motor or motor_por_defecto()
    def fin(texto, persona, fuente=None):
        _registrar(s, "asistente", "ciudadania", motor, pregunta, texto, persona)
        return {"respuesta": texto, "paso_a_persona": persona, "fuente": fuente, "modelo": motor.nombre}
    if _QUEJA.search(pregunta):
        return fin(MSG_PERSONA, True)
    if _CASO.search(pregunta) and not autenticado:
        return fin(MSG_AUTENTICAR, False)
    if not documentos:
        return fin(MSG_SIN_FUENTE, True)
    titulos = [d["titulo"] for d in documentos]
    sistema = ("Respondes preguntas de damnificados de un sismo en Colombia, en lenguaje llano y amable, en máximo 90 palabras. Usa "
               "exclusivamente los documentos oficiales que se entregan. Termina con una línea exacta «Fuente: <título del documento>». "
               "Si los documentos no contienen la respuesta, responde solo «SIN_FUENTE». No apruebas ni niegas apoyos.")
    cuerpo = "\n\n".join(f"### {d['titulo']}\n{d['texto']}" for d in documentos) + f"\n\nPregunta: {pregunta}"
    texto = _generar(motor, sistema, cuerpo)
    m = re.search(r"Fuente:\s*(.+)\s*$", texto)
    fuente = m.group(1).strip().strip(".«»\"") if m else None
    if not texto or "SIN_FUENTE" in texto or fuente not in titulos:
        return fin(MSG_SIN_FUENTE, True)  # sin cita válida no hay respuesta automática
    return fin(texto, False, fuente)


# ---------------------------------------------------------------- 3. revisión documental
def revisar_documento(s: Session, texto: str, requisitos: list[str], actor: str, motor: Motor | None = None) -> dict:
    """Marca qué requisitos de la lista no aparecen en un pliego o contrato público. Decide el jefe jurídico."""
    motor = motor or motor_por_defecto()
    bajo = texto.lower()
    faltan = [r for r in requisitos if r.lower() not in bajo]  # verificación literal, determinista
    sistema = ("Eres abogado de contratación estatal en Colombia. Con base solo en el documento, comenta en máximo 150 palabras los "
               "requisitos que parecen faltar y dónde debería revisarse. No concluyas sobre la legalidad.")
    comentario = _generar(motor, sistema, f"Requisitos sin coincidencia literal: {faltan}\n\nDocumento:\n{texto[:12000]}") if faltan else ""
    salida = {"requisitos": len(requisitos), "sin_coincidencia": faltan, "comentario": comentario, "modelo": motor.nombre,
              "nota": "Coincidencia literal: un requisito puede estar redactado con otras palabras. Decide el jefe jurídico."}
    _registrar(s, "revisar_documento", actor, motor, texto, canonico(salida))
    return salida


# ---------------------------------------------------------------- 4. agente auditor
def auditor(s: Session, actor: str = "sistema", motor: Motor | None = None) -> dict:
    """Auditoría continua. Los hallazgos son deterministas; el modelo solo redacta el resumen."""
    motor = motor or motor_por_defecto()
    cadena = bitacora.verificar(s)
    from ..servicios import _tsa
    sellos = bitacora.verificar_sellos(s, _tsa())
    pagados = s.execute(select(Hito).where(Hito.estado == "pagado")).scalars().all()
    hall = []
    if not cadena["integra"]:
        hall.append({"gravedad": "crítica", "hallazgo": f"La bitácora se rompe en el evento {cadena['ruptura_en']}"})
    if sellos["no_coinciden"]:
        hall.append({"gravedad": "crítica", "hallazgo": f"{len(sellos['no_coinciden'])} sellos de tiempo no coinciden con la cadena"})
    for h in pagados:
        if not h.acta_firmada or not h.evidencias:
            hall.append({"gravedad": "alta", "hallazgo": f"Hito {h.numero} del contrato {h.contrato_id} pagado sin acta o sin evidencia"})
        if h.plazo_pago and h.pagado and h.pagado > h.plazo_pago:
            hall.append({"gravedad": "media", "hallazgo": f"Hito {h.numero} del contrato {h.contrato_id} pagado fuera del plazo de 5 días hábiles"})
    bloqueados = s.execute(select(func.count()).select_from(Evento).where(Evento.tipo == "intento_bloqueado")).scalar()
    hechos = {"eventos": cadena["eventos"], "cadena_integra": cadena["integra"], "sellos": sellos["sellos"], "hitos_pagados": len(pagados),
              "intentos_bloqueados": bloqueados, "hallazgos": hall}
    sistema = ("Eres auditor interno. Redacta en español, en máximo 120 palabras, un resumen ejecutivo de la auditoría continua con "
               "los hechos dados, sin agregar ninguno. Si no hay hallazgos, dilo en una frase.")
    informe = _generar(motor, sistema, canonico(hechos)) or (
        f"Auditoría continua: {cadena['eventos']} eventos en la bitácora, cadena {'íntegra' if cadena['integra'] else 'ROTA'}, "
        f"{len(pagados)} hitos pagados, {bloqueados} intentos bloqueados y {len(hall)} hallazgos.")
    _registrar(s, "auditor", actor, motor, canonico(hechos), informe)
    return {**hechos, "informe": informe, "modelo": motor.nombre}
