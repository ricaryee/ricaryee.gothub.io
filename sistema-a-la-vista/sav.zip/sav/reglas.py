"""Las doce reglas de la sección 14.4 como código.

Cada regla es una función pura: recibe datos y devuelve una Activacion o None.
Ninguna escribe en la base ni decide sanciones; la API registra la activación
en la bitácora y aplica la consecuencia de procedimiento. Los umbrales viven en
`Umbrales` y solo deberían cambiar por acuerdo del Consejo Directivo.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import date
from . import calendario as cal


@dataclass(frozen=True)
class Umbrales:
    spi_atraso: float = 0.90
    spi_crisis: float = 0.80          # supuesto del prototipo: lo fija el Consejo
    adicion_comite: float = 0.30
    adicion_proceso_nuevo: float = 0.50
    un_oferente_max: float = 0.15
    precio_max: float = 1.15
    plazos_bloqueo: tuple = (2, 3, 5, 5, 5)
    dias_alerta_riesgo: int = 10
    dias_alerta_anomalia: int = 5
    dias_hallazgo: int = 20
    dias_plan_recuperacion: int = 10
    dias_crisis: int = 15
    horas_bandera: int = 48


U = Umbrales()

REGLAS = {
    1: ("Ficha incompleta", "Líder de ventanilla"),
    2: ("Proceso sin publicar", "Fiducoldex"),
    3: ("Hito sin evidencia", "Interventoría"),
    4: ("Adición fuera de regla", "Comité de contratación"),
    5: ("Atraso", "Ejecutor y líder de ventanilla"),
    6: ("Crisis", "Gerente y Consejo"),
    7: ("Bloqueo vencido", "Dueño del bloqueo"),
    8: ("Bandera roja", "Unidad de datos y control interno"),
    9: ("Alerta o petición sin respuesta", "Gerencia"),
    10: ("Poca competencia", "Comité de contratación"),
    11: ("Hallazgo sin plan", "Responsable del proceso"),
    12: ("Riesgo electoral", "Gerente zonal"),
}


@dataclass
class Activacion:
    regla: int
    accion: str
    datos: dict = field(default_factory=dict)
    vence: date | None = None
    bloquea: bool = False

    @property
    def nombre(self) -> str:
        return REGLAS[self.regla][0]

    @property
    def responsable(self) -> str:
        return REGLAS[self.regla][1]

    def como_dict(self) -> dict:
        d = asdict(self)
        d.update(nombre=self.nombre, responsable=self.responsable, vence=self.vence.isoformat() if self.vence else None)
        return d


CAMPOS_FICHA = ("nombre", "municipio_dane", "sector", "valor", "bpin", "admisibilidad", "poligono", "cronograma")


def r1_ficha(ficha: dict) -> Activacion | None:
    faltan = [c for c in CAMPOS_FICHA if ficha.get(c) in (None, "", [], {})]
    if faltan:
        return Activacion(1, "No entra a la agenda del Consejo ni del comité", {"faltan": faltan}, bloquea=True)


def r2_publicacion(id_secop: str | None, publicado: bool) -> Activacion | None:
    if not id_secop or not publicado:
        return Activacion(2, "Fiducoldex se abstiene de firmar o pagar", {"id_secop": id_secop, "publicado": publicado}, bloquea=True)


def r3_evidencia(acta_firmada: bool, fotos: int, fotos_en_geocerca: int, sellos_validos: int, minimo_fotos: int = 1) -> Activacion | None:
    ok = acta_firmada and fotos >= minimo_fotos and fotos_en_geocerca == fotos and sellos_validos == fotos
    if not ok:
        return Activacion(3, "No hay orden de pago; el hito vuelve al ejecutor",
                          {"acta_firmada": acta_firmada, "fotos": fotos, "en_geocerca": fotos_en_geocerca, "sellos_validos": sellos_validos}, bloquea=True)


def r4_adicion(valor_inicial: float, adiciones: float, aprobada_comite: bool, u: Umbrales = U) -> Activacion | None:
    if valor_inicial <= 0:
        raise ValueError("el valor inicial debe ser positivo")
    p = adiciones / valor_inicial
    if p > u.adicion_proceso_nuevo:
        return Activacion(4, "Se abre un proceso nuevo", {"porcentaje": round(p, 4)}, bloquea=True)
    if p > u.adicion_comite and not aprobada_comite:
        return Activacion(4, "Fiducoldex no firma", {"porcentaje": round(p, 4), "aprobada_comite": False}, bloquea=True)


def spi(valor_ganado: float, valor_planeado: float) -> float:
    return valor_ganado / valor_planeado if valor_planeado else 1.0


def cpi(valor_ganado: float, costo_real: float) -> float:
    return valor_ganado / costo_real if costo_real else 1.0


def r5_r6_avance(vg: float, vp: float, corte: date, spi_corte_anterior: float | None = None, u: Umbrales = U) -> Activacion | None:
    s = spi(vg, vp)
    if s < u.spi_crisis and spi_corte_anterior is not None and spi_corte_anterior < u.spi_crisis:
        return Activacion(6, "La gerencia zonal asume la coordinación; el Consejo decide si cambia de ejecutor",
                          {"spi": round(s, 3), "spi_anterior": round(spi_corte_anterior, 3)}, cal.sumar_habiles(corte, u.dias_crisis))
    if s < u.spi_atraso:
        return Activacion(5, "Plan de recuperación aprobado en el comité de gerencia", {"spi": round(s, 3)}, cal.sumar_habiles(corte, u.dias_plan_recuperacion))


def nivel_bloqueo(dias_habiles: int, u: Umbrales = U) -> int:
    acum = 0
    for nivel, plazo in enumerate(u.plazos_bloqueo, start=1):
        acum += plazo
        if dias_habiles <= acum:
            return nivel
    return len(u.plazos_bloqueo)


def r7_bloqueo(abierto: date, hoy: date, nivel_registrado: int, u: Umbrales = U) -> Activacion | None:
    d = cal.habiles_entre(abierto, hoy)
    nivel = nivel_bloqueo(d, u)
    vencido = d > sum(u.plazos_bloqueo)
    if nivel > nivel_registrado or vencido:
        return Activacion(7, "Vencido: va al Consejo Directivo" if vencido else f"Sube al nivel {nivel}",
                          {"dias_habiles": d, "nivel": nivel, "vencido": vencido})


def r8_bandera(confirmada: bool) -> Activacion | None:
    if confirmada:
        return Activacion(8, "Se retiene el siguiente pago y se avisa al Observatorio", {"confirmada": True}, bloquea=True)


def plazo_alerta(tipo: str, recibida: date, u: Umbrales = U) -> date | None:
    if tipo == "riesgo":
        return cal.sumar_habiles(recibida, u.dias_alerta_riesgo)
    if tipo == "anomalia":
        return cal.sumar_habiles(recibida, u.dias_alerta_anomalia)
    if tipo == "irregular":
        return None  # se traslada a la autoridad competente
    raise ValueError(f"tipo de alerta desconocido: {tipo}")


def r9_alerta(tipo: str, recibida: date, hoy: date, respondida_con_evidencia: bool, u: Umbrales = U) -> Activacion | None:
    vence = plazo_alerta(tipo, recibida, u)
    if vence and hoy > vence and not respondida_con_evidencia:
        return Activacion(9, "Se publica «sin respuesta» y va a la mesa de control preventivo",
                          {"vencio": vence.isoformat(), "publicar": cal.sumar_habiles(vence, 1).isoformat()})


def r10_competencia(procesos: int, con_un_oferente: int, u: Umbrales = U) -> Activacion | None:
    if procesos and con_un_oferente / procesos > u.un_oferente_max:
        return Activacion(10, "Revisión de pliegos con CCE y pliego tipo obligatorio", {"porcentaje": round(con_un_oferente / procesos, 4)})


def r11_hallazgo(notificado: date, hoy: date, plan_radicado: bool, u: Umbrales = U) -> Activacion | None:
    if not plan_radicado and cal.habiles_entre(notificado, hoy) >= u.dias_hallazgo:
        return Activacion(11, "Se reporta al comité de auditoría y se publica", {"dias_habiles": cal.habiles_entre(notificado, hoy)})


def r12_electoral(acto_con_candidato: bool) -> Activacion | None:
    if acto_con_candidato:
        return Activacion(12, "Se suspende el acto, se reprograma y se informa al CNE y a la Procuraduría", {}, bloquea=True)
