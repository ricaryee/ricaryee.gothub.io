"""Modelo de datos. SQLite para desarrollo y pruebas; PostgreSQL en producción."""
from __future__ import annotations
from datetime import date, datetime, timezone
from sqlalchemy import (JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint, create_engine, event, text)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from . import config


def ahora() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Proyecto(Base):
    __tablename__ = "proyectos"
    id_sismo: Mapped[str] = mapped_column(String(32), primary_key=True)
    nombre: Mapped[str] = mapped_column(String(300))
    municipio_dane: Mapped[str] = mapped_column(String(5), index=True)
    municipio: Mapped[str] = mapped_column(String(80), default="")
    zona: Mapped[int] = mapped_column(Integer, default=0)
    sector: Mapped[str] = mapped_column(String(3))
    valor: Mapped[float] = mapped_column(Float)
    ficha: Mapped[dict] = mapped_column(JSON)
    es_vivienda: Mapped[bool] = mapped_column(Boolean, default=False)
    creado: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    contratos: Mapped[list["Contrato"]] = relationship(back_populates="proyecto")


class Contrato(Base):
    __tablename__ = "contratos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    id_sismo: Mapped[str] = mapped_column(ForeignKey("proyectos.id_sismo"), index=True)
    id_secop: Mapped[str | None] = mapped_column(String(40), nullable=True, index=True)
    publicado: Mapped[bool] = mapped_column(Boolean, default=False)
    contratista: Mapped[str] = mapped_column(String(200))
    representante: Mapped[str] = mapped_column(String(200), default="")
    constitucion_contratista: Mapped[date | None] = mapped_column(Date, nullable=True)
    oferentes: Mapped[int] = mapped_column(Integer, default=0)
    valor_inicial: Mapped[float] = mapped_column(Float)
    adiciones: Mapped[float] = mapped_column(Float, default=0)
    adicion_aprobada: Mapped[bool] = mapped_column(Boolean, default=False)
    inmuebles: Mapped[bool] = mapped_column(Boolean, default=False)
    banda: Mapped[str] = mapped_column(String(8))
    aprobado_por: Mapped[str | None] = mapped_column(String(80), nullable=True)
    firmado: Mapped[bool] = mapped_column(Boolean, default=False)
    firma: Mapped[date | None] = mapped_column(Date, nullable=True)
    items: Mapped[list] = mapped_column(JSON, default=list)
    spi_anterior: Mapped[float | None] = mapped_column(Float, nullable=True)
    proyecto: Mapped[Proyecto] = relationship(back_populates="contratos")
    hitos: Mapped[list["Hito"]] = relationship(back_populates="contrato", order_by="Hito.numero")


class Hito(Base):
    __tablename__ = "hitos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    contrato_id: Mapped[int] = mapped_column(ForeignKey("contratos.id"), index=True)
    numero: Mapped[int] = mapped_column(Integer)
    valor: Mapped[float] = mapped_column(Float)
    valor_planeado: Mapped[float] = mapped_column(Float, default=0)   # VP acumulado al corte
    valor_ganado: Mapped[float] = mapped_column(Float, default=0)     # VG acumulado certificado
    estado: Mapped[str] = mapped_column(String(12), default="pendiente")  # pendiente|certificado|autorizado|pagado|devuelto
    acta_firmada: Mapped[bool] = mapped_column(Boolean, default=False)
    orden_pago: Mapped[date | None] = mapped_column(Date, nullable=True)
    plazo_pago: Mapped[date | None] = mapped_column(Date, nullable=True)
    pagado: Mapped[date | None] = mapped_column(Date, nullable=True)
    contrato: Mapped[Contrato] = relationship(back_populates="hitos")
    evidencias: Mapped[list["Evidencia"]] = relationship(back_populates="hito")


class Evidencia(Base):
    __tablename__ = "evidencias"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    hito_id: Mapped[int] = mapped_column(ForeignKey("hitos.id"), index=True)
    huella: Mapped[str] = mapped_column(String(64), index=True)
    lon: Mapped[float] = mapped_column(Float)
    lat: Mapped[float] = mapped_column(Float)
    capturada: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    sello: Mapped[dict] = mapped_column(JSON)
    en_geocerca: Mapped[bool] = mapped_column(Boolean)
    hora_coherente: Mapped[bool] = mapped_column(Boolean)
    repetida: Mapped[bool] = mapped_column(Boolean, default=False)
    hito: Mapped[Hito] = relationship(back_populates="evidencias")


class Bloqueo(Base):
    __tablename__ = "bloqueos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    id_sismo: Mapped[str] = mapped_column(String(32), index=True)
    descripcion: Mapped[str] = mapped_column(String(300))
    dueno: Mapped[str] = mapped_column(String(120))
    abierto: Mapped[date] = mapped_column(Date)
    nivel: Mapped[int] = mapped_column(Integer, default=1)
    vencido: Mapped[bool] = mapped_column(Boolean, default=False)
    cerrado: Mapped[date | None] = mapped_column(Date, nullable=True)


class Bandera(Base):
    __tablename__ = "banderas"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    bandera: Mapped[int] = mapped_column(Integer)
    nombre: Mapped[str] = mapped_column(String(80))
    referencia: Mapped[str] = mapped_column(String(80), index=True)
    dato: Mapped[str] = mapped_column(String(300))
    decide: Mapped[str] = mapped_column(String(60))
    contrato_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    detectada: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    estado: Mapped[str] = mapped_column(String(12), default="revision")  # revision|confirmada|descartada
    motivo: Mapped[str] = mapped_column(Text, default="")
    decidida_por: Mapped[str | None] = mapped_column(String(80), nullable=True)


class Alerta(Base):
    __tablename__ = "alertas"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tipo: Mapped[str] = mapped_column(String(10))  # riesgo|anomalia|irregular
    texto: Mapped[str] = mapped_column(Text)
    municipio: Mapped[str] = mapped_column(String(80), default="")
    recibida: Mapped[date] = mapped_column(Date)
    vence: Mapped[date | None] = mapped_column(Date, nullable=True)
    estado: Mapped[str] = mapped_column(String(16), default="en_plazo")  # en_plazo|cerrada|sin_respuesta|trasladada
    respuesta: Mapped[str] = mapped_column(Text, default="")
    evidencia_respuesta: Mapped[str] = mapped_column(Text, default="")


class Activacion(Base):
    __tablename__ = "activaciones"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    regla: Mapped[int] = mapped_column(Integer, index=True)
    referencia: Mapped[str] = mapped_column(String(80), index=True)
    accion: Mapped[str] = mapped_column(String(200))
    responsable: Mapped[str] = mapped_column(String(80))
    datos: Mapped[dict] = mapped_column(JSON)
    vence: Mapped[date | None] = mapped_column(Date, nullable=True)
    abierta: Mapped[bool] = mapped_column(Boolean, default=True)
    creada: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)


class RevisionSatelital(Base):
    __tablename__ = "revisiones_satelitales"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    id_sismo: Mapped[str] = mapped_column(String(32), index=True)
    desde: Mapped[date] = mapped_column(Date)
    hasta: Mapped[date] = mapped_column(Date)
    estado: Mapped[str] = mapped_column(String(20))
    resultado: Mapped[dict] = mapped_column(JSON)
    creada: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)


class Evento(Base):
    """Bitácora de solo escritura. Cada evento guarda la huella del anterior."""
    __tablename__ = "eventos"
    seq: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=False)
    ts: Mapped[str] = mapped_column(String(40))
    referencia: Mapped[str] = mapped_column(String(80), index=True)
    tipo: Mapped[str] = mapped_column(String(40), index=True)
    actor: Mapped[str] = mapped_column(String(80))
    rol: Mapped[str] = mapped_column(String(30))
    datos: Mapped[str] = mapped_column(Text)  # JSON canónico
    anterior: Mapped[str] = mapped_column(String(64))
    huella: Mapped[str] = mapped_column(String(64))


class Sello(Base):
    __tablename__ = "sellos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    seq: Mapped[int] = mapped_column(Integer)
    huella: Mapped[str] = mapped_column(String(64))
    sello: Mapped[dict] = mapped_column(JSON)


class Acceso(Base):
    __tablename__ = "accesos"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    actor: Mapped[str] = mapped_column(String(80))
    rol: Mapped[str] = mapped_column(String(30))
    metodo: Mapped[str] = mapped_column(String(8))
    ruta: Mapped[str] = mapped_column(String(300))
    estado: Mapped[int] = mapped_column(Integer)


class DocumentoOficial(Base):
    """Lo único que el asistente puede citar. Lo publica una persona; el asistente no escribe aquí."""
    __tablename__ = "documentos_oficiales"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    titulo: Mapped[str] = mapped_column(String(200), unique=True)
    texto: Mapped[str] = mapped_column(Text)
    vigente: Mapped[bool] = mapped_column(Boolean, default=True)
    publicado_por: Mapped[str] = mapped_column(String(80))
    actualizado: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)

class Contacto(Base):
    """Quien escribe por un canal, identificado solo por seudónimo. El número no se guarda aquí."""
    __tablename__ = "contactos"
    seudonimo: Mapped[str] = mapped_column(String(32), primary_key=True)
    canal: Mapped[str] = mapped_column(String(12))
    primer_contacto: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    baja: Mapped[bool] = mapped_column(Boolean, default=False)

class MensajeCanal(Base):
    __tablename__ = "mensajes_canal"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    id_externo: Mapped[str] = mapped_column(String(200), unique=True)   # el proveedor reintenta: un mismo mensaje se atiende una vez
    canal: Mapped[str] = mapped_column(String(12))
    contacto: Mapped[str] = mapped_column(String(32), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora, index=True)
    entrada_huella: Mapped[str] = mapped_column(String(64))
    respuesta: Mapped[str] = mapped_column(Text, default="")
    paso_a_persona: Mapped[bool] = mapped_column(Boolean, default=False)

class CasoAtencion(Base):
    """Lo que el asistente no puede responder. Aquí sí se guarda el número: sin él nadie puede devolver la respuesta."""
    __tablename__ = "casos_atencion"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    canal: Mapped[str] = mapped_column(String(12))
    contacto: Mapped[str] = mapped_column(String(32), index=True)
    numero: Mapped[str] = mapped_column(String(255))   # cifrado; vacío cuando la respuesta ya se entregó
    pregunta: Mapped[str] = mapped_column(Text)
    abierto: Mapped[date] = mapped_column(Date)
    vence: Mapped[date] = mapped_column(Date)
    estado: Mapped[str] = mapped_column(String(10), default="abierto")  # abierto|cerrado
    respuesta: Mapped[str] = mapped_column(Text, default="")
    atendido_por: Mapped[str | None] = mapped_column(String(80), nullable=True)
    entregada: Mapped[bool] = mapped_column(Boolean, default=False)

class Duplicado(Base):
    """Coincidencia entre un proyecto del Fondo y una intervención registrada por la UNGRD. La decide una persona."""
    __tablename__ = "duplicados"
    __table_args__ = (UniqueConstraint("id_sismo", "id_ungrd"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    id_sismo: Mapped[str] = mapped_column(String(32), index=True)
    id_ungrd: Mapped[str] = mapped_column(String(80))
    nombre_ungrd: Mapped[str] = mapped_column(String(300), default="")
    nivel: Mapped[str] = mapped_column(String(6))   # alto|medio
    puntaje: Mapped[float] = mapped_column(Float)
    motivos: Mapped[list] = mapped_column(JSON)
    detectado: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    estado: Mapped[str] = mapped_column(String(12), default="revision")  # revision|confirmado|descartado
    motivo: Mapped[str] = mapped_column(Text, default="")
    decidido_por: Mapped[str | None] = mapped_column(String(80), nullable=True)

class ConsultaIA(Base):
    __tablename__ = "consultas_ia"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=ahora)
    uso: Mapped[str] = mapped_column(String(40))
    actor: Mapped[str] = mapped_column(String(80))
    modelo: Mapped[str] = mapped_column(String(60))
    entrada_huella: Mapped[str] = mapped_column(String(64))
    salida: Mapped[str] = mapped_column(Text)
    paso_a_persona: Mapped[bool] = mapped_column(Boolean, default=False)


_SOLO_ESCRITURA = ("eventos", "sellos", "accesos", "consultas_ia")


def crear_motor(url: str | None = None):
    url = url or config.DB_URL()
    kw = {"connect_args": {"check_same_thread": False}} if url.startswith("sqlite") else {}
    motor = create_engine(url, **kw)
    if url.startswith("sqlite"):
        @event.listens_for(motor, "connect")
        def _fk(dbapi, _):
            dbapi.execute("PRAGMA foreign_keys=ON")
    return motor


def crear_esquema(motor):
    """Crea tablas y los candados que impiden modificar o borrar los registros de auditoría."""
    Base.metadata.create_all(motor)
    with motor.begin() as c:
        if motor.dialect.name == "sqlite":
            for t in _SOLO_ESCRITURA:
                for op in ("UPDATE", "DELETE"):
                    c.execute(text(f"CREATE TRIGGER IF NOT EXISTS {t}_{op.lower()}_prohibido BEFORE {op} ON {t} "
                                   f"BEGIN SELECT RAISE(ABORT, '{t}: registro de solo escritura'); END"))
        elif motor.dialect.name == "postgresql":
            c.execute(text("CREATE OR REPLACE FUNCTION sav_solo_escritura() RETURNS trigger AS $$ "
                           "BEGIN RAISE EXCEPTION '%: registro de solo escritura', TG_TABLE_NAME; END $$ LANGUAGE plpgsql"))
            for t in _SOLO_ESCRITURA:
                c.execute(text(f"DROP TRIGGER IF EXISTS {t}_inmutable ON {t}"))
                c.execute(text(f"CREATE TRIGGER {t}_inmutable BEFORE UPDATE OR DELETE ON {t} "
                               f"FOR EACH ROW EXECUTE FUNCTION sav_solo_escritura()"))


def fabrica(motor):
    return sessionmaker(motor, expire_on_commit=False)
